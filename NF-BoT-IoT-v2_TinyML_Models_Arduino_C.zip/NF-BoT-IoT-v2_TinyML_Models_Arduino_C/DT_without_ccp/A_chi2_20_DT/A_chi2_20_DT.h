#pragma once
namespace Eloquent {
    namespace ML {
        namespace Port {
            class DecisionTree {
                public:
                    /**
                    * Predict class for features vector
                    */
                    int predict(float *x) {
                        if (x[4] <= 1.2995810508728027) {
                            if (x[1] <= -0.11818376183509827) {
                                if (x[4] <= 0.13686902076005936) {
                                    if (x[6] <= 0.5) {
                                        if (x[0] <= 0.2158508002758026) {
                                            if (x[1] <= -26.487513072788715) {
                                                return 0;
                                            }

                                            else {
                                                return 0;
                                            }
                                        }

                                        else {
                                            return 0;
                                        }
                                    }

                                    else {
                                        return 1;
                                    }
                                }

                                else {
                                    return 0;
                                }
                            }

                            else {
                                if (x[9] <= 0.5) {
                                    if (x[5] <= 0.5) {
                                        if (x[8] <= 0.5) {
                                            if (x[4] <= -0.16151637583971024) {
                                                if (x[0] <= 1.9136982560157776) {
                                                    if (x[7] <= 0.5) {
                                                        if (x[1] <= -0.11813401058316231) {
                                                            return 0;
                                                        }

                                                        else {
                                                            return 0;
                                                        }
                                                    }

                                                    else {
                                                        return 1;
                                                    }
                                                }

                                                else {
                                                    if (x[0] <= 10.760615348815918) {
                                                        return 1;
                                                    }

                                                    else {
                                                        return 0;
                                                    }
                                                }
                                            }

                                            else {
                                                return 1;
                                            }
                                        }

                                        else {
                                            if (x[1] <= 9.700222492218018) {
                                                if (x[1] <= -0.11818307638168335) {
                                                    if (x[4] <= -0.08862666040658951) {
                                                        if (x[1] <= -0.11818327382206917) {
                                                            return 1;
                                                        }

                                                        else {
                                                            if (x[7] <= 0.5) {
                                                                return 1;
                                                            }

                                                            else {
                                                                return 0;
                                                            }
                                                        }
                                                    }

                                                    else {
                                                        return 0;
                                                    }
                                                }

                                                else {
                                                    if (x[4] <= 0.06750267371535301) {
                                                        if (x[1] <= -0.11818088963627815) {
                                                            if (x[1] <= -0.11818252503871918) {
                                                                if (x[4] <= -0.07915760204195976) {
                                                                    if (x[4] <= -0.17318753898143768) {
                                                                        if (x[1] <= -0.11818265914916992) {
                                                                            if (x[1] <= -0.11818280816078186) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                return 1;
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }

                                                            else {
                                                                if (x[1] <= -0.11818145588040352) {
                                                                    if (x[4] <= -0.20115428417921066) {
                                                                        if (x[6] <= 0.5) {
                                                                            return 1;
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[1] <= -0.1181812584400177) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        if (x[4] <= -0.08862666040658951) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            if (x[0] <= 0.4286476820707321) {
                                                                if (x[1] <= -0.11817904934287071) {
                                                                    if (x[1] <= -0.11817929521203041) {
                                                                        if (x[4] <= -0.2007138654589653) {
                                                                            if (x[1] <= -0.11818031594157219) {
                                                                                return 1;
                                                                            }

                                                                            else {
                                                                                return 1;
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }

                                                            else {
                                                                if (x[7] <= 0.5) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    if (x[4] <= -0.08708518370985985) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        if (x[4] <= -0.014635888859629631) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }

                                                    else {
                                                        if (x[1] <= -0.11816532164812088) {
                                                            if (x[4] <= 0.18025051429867744) {
                                                                return 0;
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }

                                                        else {
                                                            if (x[7] <= 0.5) {
                                                                return 0;
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            else {
                                                if (x[0] <= 8.84997147321701) {
                                                    return 0;
                                                }

                                                else {
                                                    return 1;
                                                }
                                            }
                                        }
                                    }

                                    else {
                                        if (x[4] <= 0.13686902076005936) {
                                            if (x[1] <= -0.11817912012338638) {
                                                if (x[1] <= -0.1181829534471035) {
                                                    if (x[8] <= 0.5) {
                                                        if (x[1] <= -0.11818327382206917) {
                                                            return 0;
                                                        }

                                                        else {
                                                            return 1;
                                                        }
                                                    }

                                                    else {
                                                        if (x[4] <= -0.08862666040658951) {
                                                            if (x[1] <= -0.11818333342671394) {
                                                                return 0;
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }

                                                        else {
                                                            return 0;
                                                        }
                                                    }
                                                }

                                                else {
                                                    if (x[4] <= -0.03863884508609772) {
                                                        if (x[8] <= 0.5) {
                                                            if (x[1] <= -0.11818216741085052) {
                                                                return 0;
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }

                                                        else {
                                                            if (x[1] <= -0.11818252503871918) {
                                                                if (x[4] <= -0.15138668566942215) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }

                                                            else {
                                                                if (x[1] <= -0.11818023025989532) {
                                                                    if (x[1] <= -0.11818094179034233) {
                                                                        if (x[1] <= -0.11818161234259605) {
                                                                            if (x[1] <= -0.1181819960474968) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[1] <= -0.11817978695034981) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }

                                                    else {
                                                        if (x[1] <= -0.11818165332078934) {
                                                            if (x[0] <= 0.003053911030292511) {
                                                                return 1;
                                                            }

                                                            else {
                                                                if (x[0] <= 0.0754954032599926) {
                                                                    return 0;
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            if (x[1] <= -0.11818042397499084) {
                                                                if (x[1] <= -0.11818091571331024) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }

                                                            else {
                                                                if (x[1] <= -0.11817993223667145) {
                                                                    return 0;
                                                                }

                                                                else {
                                                                    if (x[1] <= -0.11817944049835205) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            else {
                                                if (x[1] <= -0.09745737165212631) {
                                                    if (x[0] <= 0.5010891892015934) {
                                                        if (x[1] <= -0.11817806586623192) {
                                                            if (x[4] <= -0.08862666040658951) {
                                                                return 1;
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }

                                                        else {
                                                            if (x[4] <= -0.08862666040658951) {
                                                                if (x[1] <= -0.11812493577599525) {
                                                                    if (x[1] <= -0.1181594505906105) {
                                                                        if (x[1] <= -0.11816814541816711) {
                                                                            if (x[1] <= -0.11817364394664764) {
                                                                                return 1;
                                                                            }

                                                                            else {
                                                                                if (x[1] <= -0.11817187815904617) {
                                                                                    return 0;
                                                                                }

                                                                                else {
                                                                                    if (x[1] <= -0.11816956847906113) {
                                                                                        return 1;
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[1] <= -0.1181587390601635) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            if (x[1] <= -0.11814701184630394) {
                                                                                if (x[1] <= -0.11815321072936058) {
                                                                                    if (x[1] <= -0.11815670132637024) {
                                                                                        return 1;
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    return 1;
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[1] <= -0.112527284771204) {
                                                                        if (x[1] <= -0.11811310797929764) {
                                                                            return 1;
                                                                        }

                                                                        else {
                                                                            if (x[1] <= -0.1180984228849411) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                if (x[1] <= -0.11720447614789009) {
                                                                                    if (x[1] <= -0.11740239337086678) {
                                                                                        if (x[1] <= -0.11776211112737656) {
                                                                                            if (x[1] <= -0.1180550679564476) {
                                                                                                if (x[1] <= -0.11807407438755035) {
                                                                                                    return 1;
                                                                                                }

                                                                                                else {
                                                                                                    return 0;
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                if (x[1] <= -0.11797943711280823) {
                                                                                                    if (x[1] <= -0.11801313236355782) {
                                                                                                        return 1;
                                                                                                    }

                                                                                                    else {
                                                                                                        return 0;
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    return 1;
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            if (x[1] <= -0.11767031252384186) {
                                                                                                return 0;
                                                                                            }

                                                                                            else {
                                                                                                return 1;
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    if (x[1] <= -0.11542129516601562) {
                                                                                        if (x[1] <= -0.1166076734662056) {
                                                                                            return 1;
                                                                                        }

                                                                                        else {
                                                                                            if (x[1] <= -0.116265919059515) {
                                                                                                return 0;
                                                                                            }

                                                                                            else {
                                                                                                return 1;
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        if (x[1] <= -0.11486632376909256) {
                                                                                            return 0;
                                                                                        }

                                                                                        else {
                                                                                            return 1;
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[1] <= -0.11184240505099297) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            if (x[1] <= -0.10508780181407928) {
                                                                                if (x[1] <= -0.10680234432220459) {
                                                                                    if (x[1] <= -0.11029252782464027) {
                                                                                        return 1;
                                                                                    }

                                                                                    else {
                                                                                        if (x[1] <= -0.10937748476862907) {
                                                                                            return 0;
                                                                                        }

                                                                                        else {
                                                                                            return 1;
                                                                                        }
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    return 0;
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 1;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                if (x[1] <= -0.11817673966288567) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }
                                                        }
                                                    }

                                                    else {
                                                        if (x[0] <= 1.34774911403656) {
                                                            if (x[0] <= 0.9945968389511108) {
                                                                return 0;
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }

                                                        else {
                                                            return 0;
                                                        }
                                                    }
                                                }

                                                else {
                                                    if (x[1] <= 1.1898810267448425) {
                                                        if (x[1] <= 0.17776360362768173) {
                                                            if (x[1] <= 0.00870030012447387) {
                                                                if (x[1] <= -0.08973947167396545) {
                                                                    if (x[1] <= -0.09281842410564423) {
                                                                        if (x[1] <= -0.09605811536312103) {
                                                                            if (x[1] <= -0.0969635546207428) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                return 1;
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }

                                                            else {
                                                                if (x[0] <= 0.3607337772846222) {
                                                                    if (x[1] <= 0.04168425314128399) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        if (x[1] <= 0.07638009637594223) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            return 0;
                                                        }
                                                    }

                                                    else {
                                                        if (x[1] <= 4.585920333862305) {
                                                            if (x[1] <= 2.0311028957366943) {
                                                                if (x[1] <= 1.274743914604187) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }

                                                        else {
                                                            if (x[1] <= 13.623398303985596) {
                                                                return 0;
                                                            }

                                                            else {
                                                                if (x[1] <= 15.06214427947998) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    if (x[1] <= 25.022135734558105) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        if (x[1] <= 27.643369674682617) {
                                                                            return 1;
                                                                        }

                                                                        else {
                                                                            if (x[1] <= 38.881235122680664) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                if (x[1] <= 45.93563461303711) {
                                                                                    return 1;
                                                                                }

                                                                                else {
                                                                                    return 0;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        else {
                                            if (x[1] <= -0.11815240606665611) {
                                                return 1;
                                            }

                                            else {
                                                return 0;
                                            }
                                        }
                                    }
                                }

                                else {
                                    if (x[4] <= 0.13686902076005936) {
                                        if (x[1] <= -0.11818302795290947) {
                                            if (x[7] <= 0.5) {
                                                if (x[4] <= -0.08862666040658951) {
                                                    if (x[6] <= 0.5) {
                                                        if (x[1] <= -0.11818327382206917) {
                                                            return 0;
                                                        }

                                                        else {
                                                            return 1;
                                                        }
                                                    }

                                                    else {
                                                        if (x[0] <= 2.9776827096939087) {
                                                            if (x[0] <= 1.2798351645469666) {
                                                                return 0;
                                                            }

                                                            else {
                                                                return 0;
                                                            }
                                                        }

                                                        else {
                                                            if (x[0] <= 3.969225525856018) {
                                                                if (x[0] <= 3.6160733699798584) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    if (x[2] <= 23.192398929968476) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                if (x[0] <= 8.93599557876587) {
                                                                    if (x[0] <= 6.586174726486206) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        if (x[0] <= 7.78598690032959) {
                                                                            return 1;
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[0] <= 10.126752853393555) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        if (x[0] <= 17.977599143981934) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }

                                                else {
                                                    return 0;
                                                }
                                            }

                                            else {
                                                if (x[1] <= -0.11818327382206917) {
                                                    return 0;
                                                }

                                                else {
                                                    if (x[4] <= -0.08862666040658951) {
                                                        return 1;
                                                    }

                                                    else {
                                                        return 0;
                                                    }
                                                }
                                            }
                                        }

                                        else {
                                            if (x[1] <= -0.11815385147929192) {
                                                if (x[1] <= -0.11818034946918488) {
                                                    if (x[4] <= -0.12474119663238525) {
                                                        if (x[1] <= -0.11818218976259232) {
                                                            return 0;
                                                        }

                                                        else {
                                                            if (x[1] <= -0.11818195879459381) {
                                                                return 1;
                                                            }

                                                            else {
                                                                if (x[1] <= -0.11818123236298561) {
                                                                    if (x[1] <= -0.11818169057369232) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }
                                                        }
                                                    }

                                                    else {
                                                        if (x[1] <= -0.11818135902285576) {
                                                            if (x[4] <= -0.100958451628685) {
                                                                if (x[0] <= 0.2882922887802124) {
                                                                    return 0;
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }

                                                        else {
                                                            return 0;
                                                        }
                                                    }
                                                }

                                                else {
                                                    if (x[4] <= -0.08708518370985985) {
                                                        return 1;
                                                    }

                                                    else {
                                                        if (x[4] <= -0.02652726322412491) {
                                                            return 0;
                                                        }

                                                        else {
                                                            return 1;
                                                        }
                                                    }
                                                }
                                            }

                                            else {
                                                if (x[4] <= -0.09919676929712296) {
                                                    if (x[7] <= 0.5) {
                                                        if (x[0] <= 0.7863275408744812) {
                                                            return 0;
                                                        }

                                                        else {
                                                            return 0;
                                                        }
                                                    }

                                                    else {
                                                        return 1;
                                                    }
                                                }

                                                else {
                                                    return 0;
                                                }
                                            }
                                        }
                                    }

                                    else {
                                        if (x[0] <= 0.22037839889526367) {
                                            if (x[5] <= 0.5) {
                                                if (x[1] <= -0.11818253621459007) {
                                                    return 1;
                                                }

                                                else {
                                                    return 1;
                                                }
                                            }

                                            else {
                                                return 1;
                                            }
                                        }

                                        else {
                                            return 0;
                                        }
                                    }
                                }
                            }
                        }

                        else {
                            if (x[1] <= -0.11818283051252365) {
                                if (x[6] <= 0.5) {
                                    return 1;
                                }

                                else {
                                    if (x[0] <= 6.305463790893555) {
                                        if (x[0] <= 2.131022810935974) {
                                            if (x[9] <= 0.5) {
                                                return 0;
                                            }

                                            else {
                                                if (x[4] <= 7.514805793762207) {
                                                    return 0;
                                                }

                                                else {
                                                    return 0;
                                                }
                                            }
                                        }

                                        else {
                                            if (x[0] <= 2.2668505907058716) {
                                                return 0;
                                            }

                                            else {
                                                return 0;
                                            }
                                        }
                                    }

                                    else {
                                        if (x[0] <= 7.7905144691467285) {
                                            if (x[10] <= 0.5) {
                                                if (x[0] <= 6.377905368804932) {
                                                    return 1;
                                                }

                                                else {
                                                    if (x[0] <= 7.663741827011108) {
                                                        return 0;
                                                    }

                                                    else {
                                                        return 1;
                                                    }
                                                }
                                            }

                                            else {
                                                if (x[4] <= 7.514805793762207) {
                                                    if (x[0] <= 7.152123689651489) {
                                                        return 1;
                                                    }

                                                    else {
                                                        if (x[0] <= 7.364920616149902) {
                                                            return 0;
                                                        }

                                                        else {
                                                            return 1;
                                                        }
                                                    }
                                                }

                                                else {
                                                    return 1;
                                                }
                                            }
                                        }

                                        else {
                                            if (x[0] <= 14.19705867767334) {
                                                if (x[0] <= 13.404730319976807) {
                                                    if (x[0] <= 12.453935623168945) {
                                                        if (x[0] <= 11.937789916992188) {
                                                            if (x[0] <= 11.820072650909424) {
                                                                if (x[0] <= 9.710214138031006) {
                                                                    if (x[3] <= 71.21702575683594) {
                                                                        if (x[0] <= 8.0712251663208) {
                                                                            if (x[0] <= 7.998783588409424) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                if (x[2] <= 23.192398929968476) {
                                                                                    return 1;
                                                                                }

                                                                                else {
                                                                                    return 0;
                                                                                }
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[9] <= 0.5) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[0] <= 9.773600101470947) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        if (x[0] <= 10.869277954101562) {
                                                                            if (x[0] <= 10.33502197265625) {
                                                                                if (x[0] <= 10.05431079864502) {
                                                                                    return 0;
                                                                                }

                                                                                else {
                                                                                    if (x[0] <= 10.135807514190674) {
                                                                                        if (x[4] <= 7.514805793762207) {
                                                                                            if (x[2] <= 23.192398929968476) {
                                                                                                return 0;
                                                                                            }

                                                                                            else {
                                                                                                return 0;
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }
                                                                            }

                                                                            else {
                                                                                if (x[4] <= 7.514805793762207) {
                                                                                    return 0;
                                                                                }

                                                                                else {
                                                                                    if (x[0] <= 10.475377559661865) {
                                                                                        return 1;
                                                                                    }

                                                                                    else {
                                                                                        if (x[3] <= 23.72595412377268) {
                                                                                            return 0;
                                                                                        }

                                                                                        else {
                                                                                            return 1;
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }

                                                                        else {
                                                                            if (x[0] <= 11.666134357452393) {
                                                                                if (x[0] <= 11.571054458618164) {
                                                                                    if (x[3] <= 23.72595412377268) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        if (x[0] <= 11.281289100646973) {
                                                                                            if (x[0] <= 11.181682109832764) {
                                                                                                return 0;
                                                                                            }

                                                                                            else {
                                                                                                if (x[10] <= 0.5) {
                                                                                                    if (x[4] <= 7.514805793762207) {
                                                                                                        return 0;
                                                                                                    }

                                                                                                    else {
                                                                                                        return 0;
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    return 0;
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    if (x[9] <= 0.5) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        return 1;
                                                                                    }
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                if (x[9] <= 0.5) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    if (x[4] <= 7.514805793762207) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            return 0;
                                                        }
                                                    }

                                                    else {
                                                        if (x[0] <= 12.95197057723999) {
                                                            if (x[4] <= 7.514805793762207) {
                                                                return 0;
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }

                                                        else {
                                                            if (x[0] <= 13.264374732971191) {
                                                                if (x[10] <= 0.5) {
                                                                    return 0;
                                                                }

                                                                else {
                                                                    if (x[0] <= 13.20551586151123) {
                                                                        if (x[3] <= 23.72595412377268) {
                                                                            return 1;
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                if (x[0] <= 13.33228874206543) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }

                                                else {
                                                    if (x[0] <= 13.671857833862305) {
                                                        if (x[8] <= 0.5) {
                                                            if (x[4] <= 7.514805793762207) {
                                                                if (x[0] <= 13.563196182250977) {
                                                                    return 0;
                                                                }

                                                                else {
                                                                    if (x[0] <= 13.61752700805664) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                if (x[0] <= 13.567723274230957) {
                                                                    if (x[0] <= 13.49528169631958) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            return 0;
                                                        }
                                                    }

                                                    else {
                                                        if (x[0] <= 13.880127429962158) {
                                                            if (x[10] <= 0.5) {
                                                                if (x[4] <= 7.514805793762207) {
                                                                    if (x[0] <= 13.803158283233643) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[0] <= 13.807685852050781) {
                                                                        if (x[0] <= 13.739771842956543) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                if (x[4] <= 7.514805793762207) {
                                                                    return 0;
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            if (x[10] <= 0.5) {
                                                                if (x[0] <= 14.106507301330566) {
                                                                    if (x[0] <= 14.052175998687744) {
                                                                        if (x[4] <= 7.514805793762207) {
                                                                            if (x[3] <= 71.21702575683594) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                return 1;
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[0] <= 14.083869457244873) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            if (x[2] <= 23.192398929968476) {
                                                                                return 1;
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }

                                                            else {
                                                                if (x[0] <= 13.993317127227783) {
                                                                    return 0;
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            else {
                                                if (x[0] <= 15.537226676940918) {
                                                    if (x[4] <= 7.514805793762207) {
                                                        if (x[0] <= 14.713204860687256) {
                                                            if (x[0] <= 14.364579677581787) {
                                                                return 0;
                                                            }

                                                            else {
                                                                if (x[3] <= 23.72595412377268) {
                                                                    if (x[9] <= 0.5) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[0] <= 14.581904411315918) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            return 0;
                                                        }
                                                    }

                                                    else {
                                                        if (x[0] <= 15.256515502929688) {
                                                            if (x[0] <= 14.22875165939331) {
                                                                if (x[10] <= 0.5) {
                                                                    return 0;
                                                                }

                                                                else {
                                                                    if (x[3] <= 23.72595412377268) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                return 0;
                                                            }
                                                        }

                                                        else {
                                                            if (x[0] <= 15.31084680557251) {
                                                                return 1;
                                                            }

                                                            else {
                                                                return 0;
                                                            }
                                                        }
                                                    }
                                                }

                                                else {
                                                    if (x[0] <= 15.577974796295166) {
                                                        return 1;
                                                    }

                                                    else {
                                                        if (x[4] <= 7.514805793762207) {
                                                            if (x[0] <= 18.81067657470703) {
                                                                if (x[0] <= 16.27522373199463) {
                                                                    return 0;
                                                                }

                                                                else {
                                                                    if (x[0] <= 16.4201078414917) {
                                                                        if (x[8] <= 0.5) {
                                                                            return 1;
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[2] <= 69.61553955078125) {
                                                                            if (x[10] <= 0.5) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                if (x[2] <= 23.192398929968476) {
                                                                                    return 1;
                                                                                }

                                                                                else {
                                                                                    return 0;
                                                                                }
                                                                            }
                                                                        }

                                                                        else {
                                                                            if (x[0] <= 17.85988140106201) {
                                                                                return 1;
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                if (x[0] <= 20.21423053741455) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            if (x[0] <= 22.360309600830078) {
                                                                if (x[0] <= 19.996906280517578) {
                                                                    if (x[0] <= 19.978795051574707) {
                                                                        if (x[0] <= 19.09138774871826) {
                                                                            if (x[0] <= 17.76933002471924) {
                                                                                if (x[0] <= 17.266767501831055) {
                                                                                    if (x[0] <= 16.406524658203125) {
                                                                                        if (x[0] <= 15.849630355834961) {
                                                                                            if (x[0] <= 15.641360759735107) {
                                                                                                if (x[9] <= 0.5) {
                                                                                                    return 0;
                                                                                                }

                                                                                                else {
                                                                                                    return 1;
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                if (x[0] <= 15.713802337646484) {
                                                                                                    if (x[9] <= 0.5) {
                                                                                                        return 0;
                                                                                                    }

                                                                                                    else {
                                                                                                        return 0;
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    if (x[9] <= 0.5) {
                                                                                                        if (x[3] <= 23.72595412377268) {
                                                                                                            return 0;
                                                                                                        }

                                                                                                        else {
                                                                                                            return 0;
                                                                                                        }
                                                                                                    }

                                                                                                    else {
                                                                                                        return 0;
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            if (x[0] <= 16.315972328186035) {
                                                                                                if (x[0] <= 16.229948043823242) {
                                                                                                    if (x[0] <= 16.171090126037598) {
                                                                                                        if (x[0] <= 16.10770320892334) {
                                                                                                            if (x[9] <= 0.5) {
                                                                                                                if (x[0] <= 15.922071933746338) {
                                                                                                                    return 0;
                                                                                                                }

                                                                                                                else {
                                                                                                                    if (x[0] <= 15.994513511657715) {
                                                                                                                        return 1;
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        return 0;
                                                                                                                    }
                                                                                                                }
                                                                                                            }

                                                                                                            else {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        }

                                                                                                        else {
                                                                                                            return 1;
                                                                                                        }
                                                                                                    }

                                                                                                    else {
                                                                                                        return 0;
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    return 1;
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                return 0;
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        if (x[0] <= 16.456327438354492) {
                                                                                            return 1;
                                                                                        }

                                                                                        else {
                                                                                            if (x[0] <= 17.126412391662598) {
                                                                                                if (x[0] <= 16.59668254852295) {
                                                                                                    if (x[0] <= 16.515186309814453) {
                                                                                                        return 0;
                                                                                                    }

                                                                                                    else {
                                                                                                        return 1;
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    if (x[0] <= 16.773259162902832) {
                                                                                                        if (x[0] <= 16.723456382751465) {
                                                                                                            if (x[0] <= 16.655542373657227) {
                                                                                                                return 0;
                                                                                                            }

                                                                                                            else {
                                                                                                                return 1;
                                                                                                            }
                                                                                                        }

                                                                                                        else {
                                                                                                            return 0;
                                                                                                        }
                                                                                                    }

                                                                                                    else {
                                                                                                        if (x[0] <= 17.053970336914062) {
                                                                                                            if (x[0] <= 16.981528282165527) {
                                                                                                                if (x[0] <= 16.84570026397705) {
                                                                                                                    if (x[10] <= 0.5) {
                                                                                                                        if (x[3] <= 23.72595412377268) {
                                                                                                                            return 0;
                                                                                                                        }

                                                                                                                        else {
                                                                                                                            return 0;
                                                                                                                        }
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        return 0;
                                                                                                                    }
                                                                                                                }

                                                                                                                else {
                                                                                                                    if (x[2] <= 23.192398929968476) {
                                                                                                                        if (x[10] <= 0.5) {
                                                                                                                            return 0;
                                                                                                                        }

                                                                                                                        else {
                                                                                                                            return 0;
                                                                                                                        }
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        return 0;
                                                                                                                    }
                                                                                                                }
                                                                                                            }

                                                                                                            else {
                                                                                                                if (x[10] <= 0.5) {
                                                                                                                    if (x[3] <= 23.72595412377268) {
                                                                                                                        return 0;
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        return 0;
                                                                                                                    }
                                                                                                                }

                                                                                                                else {
                                                                                                                    return 1;
                                                                                                                }
                                                                                                            }
                                                                                                        }

                                                                                                        else {
                                                                                                            return 0;
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                if (x[9] <= 0.5) {
                                                                                                    if (x[0] <= 17.198853492736816) {
                                                                                                        if (x[2] <= 46.40396966971457) {
                                                                                                            return 0;
                                                                                                        }

                                                                                                        else {
                                                                                                            return 0;
                                                                                                        }
                                                                                                    }

                                                                                                    else {
                                                                                                        return 1;
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    if (x[0] <= 17.198853492736816) {
                                                                                                        if (x[3] <= 23.72595412377268) {
                                                                                                            return 0;
                                                                                                        }

                                                                                                        else {
                                                                                                            return 0;
                                                                                                        }
                                                                                                    }

                                                                                                    else {
                                                                                                        if (x[2] <= 23.192398929968476) {
                                                                                                            return 0;
                                                                                                        }

                                                                                                        else {
                                                                                                            if (x[2] <= 69.61553955078125) {
                                                                                                                return 0;
                                                                                                            }

                                                                                                            else {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    if (x[0] <= 17.701416015625) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        if (x[0] <= 17.76027488708496) {
                                                                                            return 1;
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }

                                                                            else {
                                                                                if (x[0] <= 17.905158042907715) {
                                                                                    if (x[0] <= 17.787440299987793) {
                                                                                        if (x[0] <= 17.778385162353516) {
                                                                                            return 1;
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        if (x[2] <= 23.192398929968476) {
                                                                                            if (x[10] <= 0.5) {
                                                                                                return 1;
                                                                                            }

                                                                                            else {
                                                                                                return 1;
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    if (x[2] <= 69.61553955078125) {
                                                                                        if (x[0] <= 18.371499061584473) {
                                                                                            if (x[9] <= 0.5) {
                                                                                                return 0;
                                                                                            }

                                                                                            else {
                                                                                                if (x[0] <= 17.918740272521973) {
                                                                                                    return 1;
                                                                                                }

                                                                                                else {
                                                                                                    if (x[0] <= 18.285475730895996) {
                                                                                                        if (x[0] <= 18.194923400878906) {
                                                                                                            if (x[0] <= 18.095316886901855) {
                                                                                                                return 0;
                                                                                                            }

                                                                                                            else {
                                                                                                                if (x[0] <= 18.140592575073242) {
                                                                                                                    return 1;
                                                                                                                }

                                                                                                                else {
                                                                                                                    if (x[3] <= 23.72595412377268) {
                                                                                                                        if (x[0] <= 18.17228603363037) {
                                                                                                                            return 0;
                                                                                                                        }

                                                                                                                        else {
                                                                                                                            if (x[0] <= 18.18586826324463) {
                                                                                                                                return 0;
                                                                                                                            }

                                                                                                                            else {
                                                                                                                                return 0;
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        if (x[0] <= 18.17228603363037) {
                                                                                                                            return 0;
                                                                                                                        }

                                                                                                                        else {
                                                                                                                            if (x[0] <= 18.18586826324463) {
                                                                                                                                return 0;
                                                                                                                            }

                                                                                                                            else {
                                                                                                                                return 0;
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }

                                                                                                        else {
                                                                                                            if (x[0] <= 18.203978538513184) {
                                                                                                                return 1;
                                                                                                            }

                                                                                                            else {
                                                                                                                if (x[0] <= 18.235671997070312) {
                                                                                                                    return 0;
                                                                                                                }

                                                                                                                else {
                                                                                                                    if (x[2] <= 23.192398929968476) {
                                                                                                                        return 0;
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        return 0;
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }

                                                                                                    else {
                                                                                                        if (x[0] <= 18.330751419067383) {
                                                                                                            if (x[0] <= 18.31716823577881) {
                                                                                                                return 0;
                                                                                                            }

                                                                                                            else {
                                                                                                                if (x[3] <= 23.72595412377268) {
                                                                                                                    return 0;
                                                                                                                }

                                                                                                                else {
                                                                                                                    return 0;
                                                                                                                }
                                                                                                            }
                                                                                                        }

                                                                                                        else {
                                                                                                            return 0;
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            if (x[0] <= 18.389610290527344) {
                                                                                                return 1;
                                                                                            }

                                                                                            else {
                                                                                                if (x[0] <= 18.892172813415527) {
                                                                                                    if (x[0] <= 18.80614948272705) {
                                                                                                        if (x[0] <= 18.711069107055664) {
                                                                                                            if (x[0] <= 18.62504482269287) {
                                                                                                                if (x[0] <= 18.534493446350098) {
                                                                                                                    if (x[0] <= 18.516383171081543) {
                                                                                                                        if (x[0] <= 18.452996253967285) {
                                                                                                                            return 0;
                                                                                                                        }

                                                                                                                        else {
                                                                                                                            if (x[0] <= 18.484689712524414) {
                                                                                                                                if (x[9] <= 0.5) {
                                                                                                                                    if (x[0] <= 18.46657943725586) {
                                                                                                                                        return 1;
                                                                                                                                    }

                                                                                                                                    else {
                                                                                                                                        if (x[3] <= 23.72595412377268) {
                                                                                                                                            return 0;
                                                                                                                                        }

                                                                                                                                        else {
                                                                                                                                            return 0;
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }

                                                                                                                                else {
                                                                                                                                    if (x[0] <= 18.46657943725586) {
                                                                                                                                        return 0;
                                                                                                                                    }

                                                                                                                                    else {
                                                                                                                                        if (x[2] <= 23.192398929968476) {
                                                                                                                                            return 0;
                                                                                                                                        }

                                                                                                                                        else {
                                                                                                                                            return 0;
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }

                                                                                                                            else {
                                                                                                                                if (x[9] <= 0.5) {
                                                                                                                                    return 0;
                                                                                                                                }

                                                                                                                                else {
                                                                                                                                    return 1;
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        return 1;
                                                                                                                    }
                                                                                                                }

                                                                                                                else {
                                                                                                                    if (x[0] <= 18.611462593078613) {
                                                                                                                        if (x[2] <= 23.192398929968476) {
                                                                                                                            return 0;
                                                                                                                        }

                                                                                                                        else {
                                                                                                                            if (x[10] <= 0.5) {
                                                                                                                                if (x[0] <= 18.570713996887207) {
                                                                                                                                    if (x[0] <= 18.548075675964355) {
                                                                                                                                        return 0;
                                                                                                                                    }

                                                                                                                                    else {
                                                                                                                                        return 0;
                                                                                                                                    }
                                                                                                                                }

                                                                                                                                else {
                                                                                                                                    return 0;
                                                                                                                                }
                                                                                                                            }

                                                                                                                            else {
                                                                                                                                return 0;
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        if (x[2] <= 23.192398929968476) {
                                                                                                                            return 0;
                                                                                                                        }

                                                                                                                        else {
                                                                                                                            return 0;
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }

                                                                                                            else {
                                                                                                                if (x[0] <= 18.69295883178711) {
                                                                                                                    if (x[0] <= 18.638628005981445) {
                                                                                                                        return 1;
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        if (x[0] <= 18.679375648498535) {
                                                                                                                            if (x[0] <= 18.65673828125) {
                                                                                                                                return 0;
                                                                                                                            }

                                                                                                                            else {
                                                                                                                                return 1;
                                                                                                                            }
                                                                                                                        }

                                                                                                                        else {
                                                                                                                            return 0;
                                                                                                                        }
                                                                                                                    }
                                                                                                                }

                                                                                                                else {
                                                                                                                    return 1;
                                                                                                                }
                                                                                                            }
                                                                                                        }

                                                                                                        else {
                                                                                                            if (x[3] <= 23.72595412377268) {
                                                                                                                if (x[0] <= 18.756345748901367) {
                                                                                                                    if (x[9] <= 0.5) {
                                                                                                                        return 0;
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        return 0;
                                                                                                                    }
                                                                                                                }

                                                                                                                else {
                                                                                                                    return 0;
                                                                                                                }
                                                                                                            }

                                                                                                            else {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        }
                                                                                                    }

                                                                                                    else {
                                                                                                        if (x[0] <= 18.855952262878418) {
                                                                                                            return 1;
                                                                                                        }

                                                                                                        else {
                                                                                                            if (x[0] <= 18.87859058380127) {
                                                                                                                return 0;
                                                                                                            }

                                                                                                            else {
                                                                                                                if (x[10] <= 0.5) {
                                                                                                                    return 1;
                                                                                                                }

                                                                                                                else {
                                                                                                                    return 0;
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    return 0;
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        if (x[0] <= 18.253782272338867) {
                                                                                            return 1;
                                                                                        }

                                                                                        else {
                                                                                            if (x[0] <= 18.31716823577881) {
                                                                                                return 0;
                                                                                            }

                                                                                            else {
                                                                                                if (x[0] <= 18.59787940979004) {
                                                                                                    return 1;
                                                                                                }

                                                                                                else {
                                                                                                    return 0;
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }

                                                                        else {
                                                                            if (x[0] <= 19.1593017578125) {
                                                                                return 1;
                                                                            }

                                                                            else {
                                                                                if (x[0] <= 19.784109115600586) {
                                                                                    if (x[0] <= 19.598477363586426) {
                                                                                        if (x[0] <= 19.440011978149414) {
                                                                                            if (x[0] <= 19.372097969055176) {
                                                                                                if (x[2] <= 23.192398929968476) {
                                                                                                    if (x[0] <= 19.295129776000977) {
                                                                                                        if (x[0] <= 19.22721576690674) {
                                                                                                            if (x[9] <= 0.5) {
                                                                                                                return 0;
                                                                                                            }

                                                                                                            else {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        }

                                                                                                        else {
                                                                                                            return 1;
                                                                                                        }
                                                                                                    }

                                                                                                    else {
                                                                                                        if (x[0] <= 19.31776714324951) {
                                                                                                            return 0;
                                                                                                        }

                                                                                                        else {
                                                                                                            if (x[10] <= 0.5) {
                                                                                                                return 0;
                                                                                                            }

                                                                                                            else {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    if (x[10] <= 0.5) {
                                                                                                        if (x[0] <= 19.31776714324951) {
                                                                                                            if (x[0] <= 19.22721576690674) {
                                                                                                                return 0;
                                                                                                            }

                                                                                                            else {
                                                                                                                if (x[0] <= 19.295129776000977) {
                                                                                                                    return 1;
                                                                                                                }

                                                                                                                else {
                                                                                                                    return 1;
                                                                                                                }
                                                                                                            }
                                                                                                        }

                                                                                                        else {
                                                                                                            return 0;
                                                                                                        }
                                                                                                    }

                                                                                                    else {
                                                                                                        return 0;
                                                                                                    }
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                return 1;
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            if (x[9] <= 0.5) {
                                                                                                if (x[3] <= 23.72595412377268) {
                                                                                                    if (x[0] <= 19.526036262512207) {
                                                                                                        return 0;
                                                                                                    }

                                                                                                    else {
                                                                                                        return 0;
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    return 0;
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                return 0;
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        if (x[0] <= 19.720722198486328) {
                                                                                            if (x[0] <= 19.639225959777832) {
                                                                                                if (x[10] <= 0.5) {
                                                                                                    if (x[3] <= 23.72595412377268) {
                                                                                                        return 0;
                                                                                                    }

                                                                                                    else {
                                                                                                        return 0;
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    if (x[3] <= 23.72595412377268) {
                                                                                                        return 0;
                                                                                                    }

                                                                                                    else {
                                                                                                        return 1;
                                                                                                    }
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                return 1;
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            if (x[0] <= 19.74336051940918) {
                                                                                                return 0;
                                                                                            }

                                                                                            else {
                                                                                                if (x[9] <= 0.5) {
                                                                                                    if (x[3] <= 23.72595412377268) {
                                                                                                        return 0;
                                                                                                    }

                                                                                                    else {
                                                                                                        return 1;
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    if (x[2] <= 23.192398929968476) {
                                                                                                        return 0;
                                                                                                    }

                                                                                                    else {
                                                                                                        return 0;
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    if (x[10] <= 0.5) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        if (x[3] <= 23.72595412377268) {
                                                                                            return 0;
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[0] <= 20.168954849243164) {
                                                                        if (x[3] <= 23.72595412377268) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            if (x[10] <= 0.5) {
                                                                                if (x[0] <= 20.09651279449463) {
                                                                                    return 0;
                                                                                }

                                                                                else {
                                                                                    return 0;
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[0] <= 21.22841167449951) {
                                                                            if (x[0] <= 21.08805561065674) {
                                                                                if (x[2] <= 69.61553955078125) {
                                                                                    if (x[0] <= 20.63982391357422) {
                                                                                        if (x[3] <= 23.72595412377268) {
                                                                                            if (x[0] <= 20.232340812683105) {
                                                                                                if (x[10] <= 0.5) {
                                                                                                    return 0;
                                                                                                }

                                                                                                else {
                                                                                                    return 0;
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                if (x[10] <= 0.5) {
                                                                                                    if (x[0] <= 20.377223014831543) {
                                                                                                        return 0;
                                                                                                    }

                                                                                                    else {
                                                                                                        return 0;
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    return 0;
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            if (x[0] <= 20.490413665771484) {
                                                                                                if (x[0] <= 20.436081886291504) {
                                                                                                    if (x[0] <= 20.232340812683105) {
                                                                                                        if (x[9] <= 0.5) {
                                                                                                            return 0;
                                                                                                        }

                                                                                                        else {
                                                                                                            return 0;
                                                                                                        }
                                                                                                    }

                                                                                                    else {
                                                                                                        return 0;
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    if (x[0] <= 20.449665069580078) {
                                                                                                        return 1;
                                                                                                    }

                                                                                                    else {
                                                                                                        if (x[10] <= 0.5) {
                                                                                                            return 0;
                                                                                                        }

                                                                                                        else {
                                                                                                            return 0;
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                return 0;
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        if (x[0] <= 20.73037624359131) {
                                                                                            if (x[2] <= 23.192398929968476) {
                                                                                                if (x[10] <= 0.5) {
                                                                                                    if (x[0] <= 20.69868278503418) {
                                                                                                        return 0;
                                                                                                    }

                                                                                                    else {
                                                                                                        return 0;
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    return 1;
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                return 0;
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            if (x[0] <= 20.7711238861084) {
                                                                                                if (x[0] <= 20.743958473205566) {
                                                                                                    if (x[10] <= 0.5) {
                                                                                                        if (x[3] <= 23.72595412377268) {
                                                                                                            return 0;
                                                                                                        }

                                                                                                        else {
                                                                                                            return 0;
                                                                                                        }
                                                                                                    }

                                                                                                    else {
                                                                                                        return 0;
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    return 0;
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                if (x[0] <= 20.79828929901123) {
                                                                                                    return 1;
                                                                                                }

                                                                                                else {
                                                                                                    if (x[0] <= 20.888842582702637) {
                                                                                                        if (x[2] <= 23.192398929968476) {
                                                                                                            if (x[0] <= 20.843565940856934) {
                                                                                                                if (x[0] <= 20.811872482299805) {
                                                                                                                    return 0;
                                                                                                                }

                                                                                                                else {
                                                                                                                    return 1;
                                                                                                                }
                                                                                                            }

                                                                                                            else {
                                                                                                                if (x[10] <= 0.5) {
                                                                                                                    if (x[0] <= 20.875259399414062) {
                                                                                                                        return 0;
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        return 0;
                                                                                                                    }
                                                                                                                }

                                                                                                                else {
                                                                                                                    return 0;
                                                                                                                }
                                                                                                            }
                                                                                                        }

                                                                                                        else {
                                                                                                            if (x[0] <= 20.839037895202637) {
                                                                                                                return 0;
                                                                                                            }

                                                                                                            else {
                                                                                                                if (x[0] <= 20.875259399414062) {
                                                                                                                    return 1;
                                                                                                                }

                                                                                                                else {
                                                                                                                    if (x[9] <= 0.5) {
                                                                                                                        return 0;
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        return 0;
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }

                                                                                                    else {
                                                                                                        if (x[0] <= 20.911479949951172) {
                                                                                                            return 0;
                                                                                                        }

                                                                                                        else {
                                                                                                            if (x[0] <= 20.934117317199707) {
                                                                                                                return 1;
                                                                                                            }

                                                                                                            else {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    return 1;
                                                                                }
                                                                            }

                                                                            else {
                                                                                if (x[3] <= 23.72595412377268) {
                                                                                    return 1;
                                                                                }

                                                                                else {
                                                                                    return 0;
                                                                                }
                                                                            }
                                                                        }

                                                                        else {
                                                                            if (x[0] <= 21.952826499938965) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                if (x[0] <= 22.00715732574463) {
                                                                                    return 1;
                                                                                }

                                                                                else {
                                                                                    if (x[3] <= 23.72595412377268) {
                                                                                        if (x[0] <= 22.079598426818848) {
                                                                                            return 0;
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            else {
                                if (x[0] <= 6.233022212982178) {
                                    if (x[4] <= 12.606075286865234) {
                                        if (x[8] <= 0.5) {
                                            if (x[1] <= -0.11708305776119232) {
                                                if (x[0] <= 4.322377920150757) {
                                                    if (x[7] <= 0.5) {
                                                        return 0;
                                                    }

                                                    else {
                                                        if (x[4] <= 7.451384902000427) {
                                                            if (x[0] <= 0.4286476969718933) {
                                                                return 1;
                                                            }

                                                            else {
                                                                return 0;
                                                            }
                                                        }

                                                        else {
                                                            return 0;
                                                        }
                                                    }
                                                }

                                                else {
                                                    if (x[0] <= 4.675530195236206) {
                                                        return 1;
                                                    }

                                                    else {
                                                        return 0;
                                                    }
                                                }
                                            }

                                            else {
                                                return 1;
                                            }
                                        }

                                        else {
                                            return 1;
                                        }
                                    }

                                    else {
                                        if (x[9] <= 0.5) {
                                            if (x[0] <= 3.964698076248169) {
                                                if (x[1] <= -0.11814827844500542) {
                                                    if (x[1] <= -0.1181793063879013) {
                                                        if (x[1] <= -0.11817984655499458) {
                                                            if (x[5] <= 0.5) {
                                                                if (x[1] <= -0.11818214505910873) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    if (x[1] <= -0.1181815043091774) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                if (x[1] <= -0.11818062141537666) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    if (x[8] <= 0.5) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            if (x[7] <= 0.5) {
                                                                return 0;
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }
                                                    }

                                                    else {
                                                        if (x[1] <= -0.11815550923347473) {
                                                            if (x[7] <= 0.5) {
                                                                if (x[1] <= -0.11817572265863419) {
                                                                    if (x[1] <= -0.11817586794495583) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        if (x[5] <= 0.5) {
                                                                            return 1;
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }

                                                            else {
                                                                if (x[1] <= -0.11816408112645149) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    if (x[1] <= -0.1181628406047821) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        if (x[1] <= -0.1181618794798851) {
                                                                            if (x[0] <= 0.007581505924463272) {
                                                                                return 1;
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            if (x[1] <= -0.11815476045012474) {
                                                                if (x[5] <= 0.5) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }
                                                    }
                                                }

                                                else {
                                                    if (x[1] <= -0.1181480810046196) {
                                                        return 0;
                                                    }

                                                    else {
                                                        if (x[7] <= 0.5) {
                                                            if (x[1] <= -0.118146151304245) {
                                                                if (x[6] <= 0.5) {
                                                                    if (x[1] <= -0.11814730614423752) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }

                                                        else {
                                                            if (x[1] <= -0.11813736334443092) {
                                                                return 1;
                                                            }

                                                            else {
                                                                if (x[1] <= -0.11807683482766151) {
                                                                    if (x[0] <= 0.003053911030292511) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[1] <= -0.11806730553507805) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        if (x[1] <= -0.11799397692084312) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            else {
                                                return 0;
                                            }
                                        }

                                        else {
                                            if (x[1] <= -0.11817381903529167) {
                                                if (x[6] <= 0.5) {
                                                    if (x[7] <= 0.5) {
                                                        if (x[1] <= -0.11817583069205284) {
                                                            if (x[1] <= -0.11817656829953194) {
                                                                return 1;
                                                            }

                                                            else {
                                                                if (x[0] <= 0.003053911030292511) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            return 1;
                                                        }
                                                    }

                                                    else {
                                                        if (x[1] <= -0.11817843466997147) {
                                                            return 1;
                                                        }

                                                        else {
                                                            if (x[1] <= -0.11817806586623192) {
                                                                if (x[0] <= 0.003053911030292511) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }
                                                    }
                                                }

                                                else {
                                                    return 0;
                                                }
                                            }

                                            else {
                                                if (x[1] <= -0.11817330121994019) {
                                                    if (x[5] <= 0.5) {
                                                        return 1;
                                                    }

                                                    else {
                                                        if (x[1] <= -0.11817356199026108) {
                                                            return 1;
                                                        }

                                                        else {
                                                            if (x[0] <= 0.0754954032599926) {
                                                                if (x[0] <= 0.003053911030292511) {
                                                                    return 0;
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }

                                                            else {
                                                                return 0;
                                                            }
                                                        }
                                                    }
                                                }

                                                else {
                                                    if (x[1] <= -0.11551059037446976) {
                                                        return 1;
                                                    }

                                                    else {
                                                        if (x[1] <= -0.11320848762989044) {
                                                            return 0;
                                                        }

                                                        else {
                                                            return 1;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                else {
                                    if (x[1] <= -0.11812654137611389) {
                                        if (x[0] <= 14.51399040222168) {
                                            if (x[1] <= -0.11818032339215279) {
                                                if (x[0] <= 10.049783706665039) {
                                                    return 0;
                                                }

                                                else {
                                                    if (x[0] <= 12.032869338989258) {
                                                        return 1;
                                                    }

                                                    else {
                                                        return 0;
                                                    }
                                                }
                                            }

                                            else {
                                                return 1;
                                            }
                                        }

                                        else {
                                            return 1;
                                        }
                                    }

                                    else {
                                        if (x[0] <= 14.23327922821045) {
                                            if (x[0] <= 13.834851264953613) {
                                                if (x[1] <= -0.11508302390575409) {
                                                    if (x[0] <= 11.181682109832764) {
                                                        if (x[0] <= 8.70961618423462) {
                                                            if (x[0] <= 7.156651258468628) {
                                                                return 0;
                                                            }

                                                            else {
                                                                if (x[0] <= 7.3468101024627686) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    if (x[0] <= 7.91275954246521) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            return 0;
                                                        }
                                                    }

                                                    else {
                                                        if (x[0] <= 12.055507183074951) {
                                                            if (x[4] <= 7.514805793762207) {
                                                                if (x[3] <= 23.72595412377268) {
                                                                    if (x[0] <= 11.747631072998047) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        if (x[0] <= 11.887986660003662) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }

                                                        else {
                                                            if (x[10] <= 0.5) {
                                                                return 0;
                                                            }

                                                            else {
                                                                if (x[0] <= 12.598818302154541) {
                                                                    return 0;
                                                                }

                                                                else {
                                                                    if (x[0] <= 13.703551292419434) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }

                                                else {
                                                    return 1;
                                                }
                                            }

                                            else {
                                                if (x[4] <= 7.514805793762207) {
                                                    return 0;
                                                }

                                                else {
                                                    if (x[0] <= 13.911820411682129) {
                                                        return 1;
                                                    }

                                                    else {
                                                        if (x[0] <= 14.015955448150635) {
                                                            return 0;
                                                        }

                                                        else {
                                                            if (x[9] <= 0.5) {
                                                                if (x[2] <= 23.192398929968476) {
                                                                    if (x[0] <= 14.156310558319092) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        else {
                                            if (x[0] <= 21.513649940490723) {
                                                if (x[0] <= 15.641360759735107) {
                                                    if (x[1] <= -0.11802536249160767) {
                                                        if (x[0] <= 15.143325805664062) {
                                                            if (x[0] <= 15.002970218658447) {
                                                                if (x[4] <= 7.514805793762207) {
                                                                    if (x[0] <= 14.509462833404541) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[0] <= 14.581904411315918) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        if (x[0] <= 14.717732429504395) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                if (x[9] <= 0.5) {
                                                                    return 0;
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            return 0;
                                                        }
                                                    }

                                                    else {
                                                        return 1;
                                                    }
                                                }

                                                else {
                                                    if (x[0] <= 15.750023365020752) {
                                                        return 1;
                                                    }

                                                    else {
                                                        if (x[0] <= 16.4201078414917) {
                                                            if (x[0] <= 16.225419998168945) {
                                                                if (x[1] <= -0.11267213150858879) {
                                                                    if (x[0] <= 15.922071933746338) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        if (x[0] <= 16.066954612731934) {
                                                                            return 1;
                                                                        }

                                                                        else {
                                                                            if (x[0] <= 16.152978897094727) {
                                                                                if (x[0] <= 16.08506488800049) {
                                                                                    return 0;
                                                                                }

                                                                                else {
                                                                                    return 1;
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }

                                                            else {
                                                                if (x[0] <= 16.257113456726074) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    if (x[2] <= 23.192398929968476) {
                                                                        if (x[0] <= 16.347665786743164) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            if (x[3] <= 118.70809555053711) {
                                                                if (x[0] <= 17.3256254196167) {
                                                                    if (x[3] <= 23.72595412377268) {
                                                                        if (x[0] <= 16.954362869262695) {
                                                                            if (x[0] <= 16.700818061828613) {
                                                                                if (x[0] <= 16.628376007080078) {
                                                                                    return 0;
                                                                                }

                                                                                else {
                                                                                    return 0;
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }

                                                                        else {
                                                                            if (x[0] <= 17.022276878356934) {
                                                                                return 1;
                                                                            }

                                                                            else {
                                                                                if (x[0] <= 17.081135749816895) {
                                                                                    if (x[9] <= 0.5) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    return 0;
                                                                                }
                                                                            }
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[0] <= 16.8728666305542) {
                                                                            if (x[0] <= 16.809480667114258) {
                                                                                if (x[0] <= 16.628376007080078) {
                                                                                    if (x[0] <= 16.55593490600586) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    if (x[0] <= 16.74156665802002) {
                                                                                        if (x[0] <= 16.67365264892578) {
                                                                                            if (x[10] <= 0.5) {
                                                                                                return 0;
                                                                                            }

                                                                                            else {
                                                                                                return 0;
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            return 1;
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 1;
                                                                            }
                                                                        }

                                                                        else {
                                                                            if (x[9] <= 0.5) {
                                                                                if (x[4] <= 7.514805793762207) {
                                                                                    return 1;
                                                                                }

                                                                                else {
                                                                                    if (x[0] <= 17.126412391662598) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        if (x[0] <= 17.198853492736816) {
                                                                                            return 1;
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[0] <= 20.033126831054688) {
                                                                        if (x[0] <= 19.70713996887207) {
                                                                            if (x[10] <= 0.5) {
                                                                                if (x[0] <= 18.11795425415039) {
                                                                                    if (x[0] <= 17.60633659362793) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        if (x[0] <= 17.674250602722168) {
                                                                                            if (x[2] <= 23.192398929968476) {
                                                                                                return 0;
                                                                                            }

                                                                                            else {
                                                                                                return 0;
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    if (x[0] <= 18.262837409973145) {
                                                                                        return 1;
                                                                                    }

                                                                                    else {
                                                                                        if (x[2] <= 53.03584671020508) {
                                                                                            if (x[0] <= 18.534493446350098) {
                                                                                                return 0;
                                                                                            }

                                                                                            else {
                                                                                                if (x[0] <= 18.588825225830078) {
                                                                                                    return 1;
                                                                                                }

                                                                                                else {
                                                                                                    if (x[0] <= 19.526036262512207) {
                                                                                                        if (x[0] <= 19.281546592712402) {
                                                                                                            if (x[0] <= 18.991780281066895) {
                                                                                                                if (x[0] <= 18.801621437072754) {
                                                                                                                    if (x[0] <= 18.69295883178711) {
                                                                                                                        if (x[0] <= 18.611462593078613) {
                                                                                                                            return 0;
                                                                                                                        }

                                                                                                                        else {
                                                                                                                            if (x[0] <= 18.62504482269287) {
                                                                                                                                if (x[3] <= 23.72595412377268) {
                                                                                                                                    return 0;
                                                                                                                                }

                                                                                                                                else {
                                                                                                                                    return 0;
                                                                                                                                }
                                                                                                                            }

                                                                                                                            else {
                                                                                                                                return 0;
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        if (x[2] <= 23.192398929968476) {
                                                                                                                            return 0;
                                                                                                                        }

                                                                                                                        else {
                                                                                                                            return 1;
                                                                                                                        }
                                                                                                                    }
                                                                                                                }

                                                                                                                else {
                                                                                                                    if (x[0] <= 18.892172813415527) {
                                                                                                                        return 1;
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        if (x[0] <= 18.93744945526123) {
                                                                                                                            return 0;
                                                                                                                        }

                                                                                                                        else {
                                                                                                                            return 1;
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }

                                                                                                            else {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        }

                                                                                                        else {
                                                                                                            if (x[0] <= 19.31776714324951) {
                                                                                                                return 1;
                                                                                                            }

                                                                                                            else {
                                                                                                                if (x[0] <= 19.39020824432373) {
                                                                                                                    return 0;
                                                                                                                }

                                                                                                                else {
                                                                                                                    if (x[3] <= 23.72595412377268) {
                                                                                                                        return 0;
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        return 0;
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }

                                                                                                    else {
                                                                                                        return 0;
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            if (x[0] <= 18.661266326904297) {
                                                                                                return 1;
                                                                                            }

                                                                                            else {
                                                                                                return 0;
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }

                                                                            else {
                                                                                if (x[0] <= 18.47110652923584) {
                                                                                    if (x[0] <= 17.624446868896484) {
                                                                                        if (x[0] <= 17.411649703979492) {
                                                                                            if (x[3] <= 23.72595412377268) {
                                                                                                return 1;
                                                                                            }

                                                                                            else {
                                                                                                return 1;
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        return 1;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    if (x[0] <= 19.530563354492188) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        return 1;
                                                                                    }
                                                                                }
                                                                            }
                                                                        }

                                                                        else {
                                                                            if (x[3] <= 23.72595412377268) {
                                                                                if (x[0] <= 19.761470794677734) {
                                                                                    if (x[10] <= 0.5) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        return 1;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    if (x[1] <= -0.11807442829012871) {
                                                                                        if (x[9] <= 0.5) {
                                                                                            return 0;
                                                                                        }

                                                                                        else {
                                                                                            if (x[0] <= 19.99237823486328) {
                                                                                                return 0;
                                                                                            }

                                                                                            else {
                                                                                                return 1;
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        return 1;
                                                                                    }
                                                                                }
                                                                            }

                                                                            else {
                                                                                if (x[0] <= 20.02407169342041) {
                                                                                    if (x[1] <= -0.11807442829012871) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        return 1;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    return 1;
                                                                                }
                                                                            }
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[4] <= 7.514805793762207) {
                                                                            if (x[3] <= 23.72595412377268) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                return 1;
                                                                            }
                                                                        }

                                                                        else {
                                                                            if (x[9] <= 0.5) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                if (x[0] <= 20.875259399414062) {
                                                                                    if (x[0] <= 20.802817344665527) {
                                                                                        if (x[0] <= 20.241395950317383) {
                                                                                            return 0;
                                                                                        }

                                                                                        else {
                                                                                            if (x[0] <= 20.517579078674316) {
                                                                                                if (x[0] <= 20.377223014831543) {
                                                                                                    if (x[3] <= 23.72595412377268) {
                                                                                                        return 0;
                                                                                                    }

                                                                                                    else {
                                                                                                        if (x[3] <= 71.21702575683594) {
                                                                                                            return 0;
                                                                                                        }

                                                                                                        else {
                                                                                                            return 0;
                                                                                                        }
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    return 1;
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                return 0;
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        return 1;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    if (x[0] <= 21.128804206848145) {
                                                                                        if (x[0] <= 21.060890197753906) {
                                                                                            return 0;
                                                                                        }

                                                                                        else {
                                                                                            return 1;
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            else {
                                                if (x[0] <= 21.67211627960205) {
                                                    return 1;
                                                }

                                                else {
                                                    return 0;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                protected:
                };
            }
        }
    }
