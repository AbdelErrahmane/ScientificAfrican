#pragma once
namespace Eloquent {
    namespace ML {
        namespace Port {
            class DecisionTree {
                public:
                    /**
                    * Predict class for features vector
                    */
                    int predict(float *x) {
                        if (x[6] <= 0.00907239131629467) {
                            if (x[4] <= 2.103878989815712) {
                                if (x[19] <= 0.5) {
                                    if (x[15] <= 0.5) {
                                        if (x[1] <= 1.3494520634412766) {
                                            return 0;
                                        }

                                        else {
                                            return 1;
                                        }
                                    }

                                    else {
                                        return 1;
                                    }
                                }

                                else {
                                    if (x[9] <= 1.2995810508728027) {
                                        if (x[14] <= 0.5) {
                                            if (x[2] <= -1.824125051498413) {
                                                if (x[6] <= 0.006921339314430952) {
                                                    if (x[15] <= 0.5) {
                                                        if (x[0] <= -0.0014874268090352416) {
                                                            if (x[9] <= 0.13686902076005936) {
                                                                if (x[10] <= 0.5) {
                                                                    if (x[11] <= 0.5) {
                                                                        if (x[9] <= -0.03093147650361061) {
                                                                            if (x[5] <= -0.11818327382206917) {
                                                                                if (x[16] <= 0.5) {
                                                                                    return 1;
                                                                                }

                                                                                else {
                                                                                    return 1;
                                                                                }
                                                                            }

                                                                            else {
                                                                                if (x[5] <= -0.11818293109536171) {
                                                                                    if (x[16] <= 0.5) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        return 1;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    return 1;
                                                                                }
                                                                            }
                                                                        }

                                                                        else {
                                                                            if (x[1] <= -0.42129506170749664) {
                                                                                return 1;
                                                                            }

                                                                            else {
                                                                                if (x[1] <= 2.4827301502227783) {
                                                                                    if (x[5] <= -0.11818263679742813) {
                                                                                        if (x[6] <= 0.006914428668096662) {
                                                                                            return 0;
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        return 1;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    if (x[0] <= -0.012161002960056067) {
                                                                                        return 1;
                                                                                    }

                                                                                    else {
                                                                                        return 1;
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[6] <= 0.006915810750797391) {
                                                                        if (x[5] <= -0.1181824617087841) {
                                                                            if (x[1] <= -0.42129506170749664) {
                                                                                if (x[5] <= -0.11818333342671394) {
                                                                                    return 0;
                                                                                }

                                                                                else {
                                                                                    if (x[5] <= -0.11818300187587738) {
                                                                                        return 1;
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }
                                                                            }

                                                                            else {
                                                                                if (x[1] <= 2.5535600185394287) {
                                                                                    if (x[6] <= 0.006914428668096662) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        if (x[1] <= 2.411900281906128) {
                                                                                            if (x[9] <= -0.03863884508609772) {
                                                                                                return 0;
                                                                                            }

                                                                                            else {
                                                                                                return 0;
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    if (x[9] <= -0.08862666040658951) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }
                                                                            }
                                                                        }

                                                                        else {
                                                                            if (x[16] <= 0.5) {
                                                                                if (x[5] <= -0.11818216741085052) {
                                                                                    return 0;
                                                                                }

                                                                                else {
                                                                                    return 1;
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 1;
                                                                            }
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[1] <= 2.1285807490348816) {
                                                                            if (x[5] <= -0.11818219348788261) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                return 1;
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                if (x[6] <= 0.006914428668096662) {
                                                                    if (x[12] <= 0.5) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        if (x[16] <= 0.5) {
                                                                            return 1;
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            if (x[10] <= 0.5) {
                                                                if (x[5] <= -0.11818066984415054) {
                                                                    if (x[6] <= 0.006916941609233618) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[5] <= -0.11817870289087296) {
                                                                        if (x[5] <= -0.11817929521203041) {
                                                                            return 1;
                                                                        }

                                                                        else {
                                                                            if (x[6] <= 0.006916941609233618) {
                                                                                return 1;
                                                                            }

                                                                            else {
                                                                                return 1;
                                                                            }
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                if (x[6] <= 0.006919454550370574) {
                                                                    if (x[0] <= 0.05188045650720596) {
                                                                        if (x[1] <= 1.2077922374010086) {
                                                                            return 1;
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }
                                                        }
                                                    }

                                                    else {
                                                        if (x[5] <= -0.11818297952413559) {
                                                            if (x[11] <= 0.5) {
                                                                if (x[1] <= 0.9244727343320847) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    if (x[6] <= 0.006915810750797391) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                return 0;
                                                            }
                                                        }

                                                        else {
                                                            if (x[1] <= 3.1201990842819214) {
                                                                return 1;
                                                            }

                                                            else {
                                                                return 0;
                                                            }
                                                        }
                                                    }
                                                }

                                                else {
                                                    if (x[5] <= -0.11818142980337143) {
                                                        if (x[3] <= 2.9776827096939087) {
                                                            if (x[6] <= 0.00692451186478138) {
                                                                return 0;
                                                            }

                                                            else {
                                                                return 0;
                                                            }
                                                        }

                                                        else {
                                                            if (x[3] <= 4.1050533056259155) {
                                                                if (x[3] <= 3.6160733699798584) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    if (x[3] <= 3.7564287185668945) {
                                                                        if (x[8] <= 23.72595412377268) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                if (x[3] <= 4.815885543823242) {
                                                                    if (x[3] <= 4.390291690826416) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }
                                                        }
                                                    }

                                                    else {
                                                        return 1;
                                                    }
                                                }
                                            }

                                            else {
                                                if (x[10] <= 0.5) {
                                                    if (x[6] <= 0.006921684835106134) {
                                                        return 1;
                                                    }

                                                    else {
                                                        if (x[9] <= -0.1540292128920555) {
                                                            return 0;
                                                        }

                                                        else {
                                                            return 1;
                                                        }
                                                    }
                                                }

                                                else {
                                                    if (x[2] <= -1.7978585958480835) {
                                                        if (x[5] <= -0.11817870289087296) {
                                                            if (x[6] <= 0.006915810750797391) {
                                                                return 0;
                                                            }

                                                            else {
                                                                if (x[0] <= -0.0014874268090352416) {
                                                                    if (x[3] <= 0.003053911030292511) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            return 1;
                                                        }
                                                    }

                                                    else {
                                                        if (x[9] <= -0.1509462669491768) {
                                                            if (x[2] <= -1.19548100233078) {
                                                                if (x[5] <= -0.11816065385937691) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    if (x[5] <= -0.118130411952734) {
                                                                        if (x[0] <= 0.041206879541277885) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }

                                                        else {
                                                            return 1;
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        else {
                                            return 0;
                                        }
                                    }

                                    else {
                                        if (x[15] <= 0.5) {
                                            if (x[0] <= 0.041206879541277885) {
                                                if (x[9] <= 12.606075286865234) {
                                                    if (x[6] <= 0.006930166389793158) {
                                                        return 1;
                                                    }

                                                    else {
                                                        return 0;
                                                    }
                                                }

                                                else {
                                                    if (x[13] <= 0.5) {
                                                        return 0;
                                                    }

                                                    else {
                                                        if (x[5] <= -0.11817818880081177) {
                                                            if (x[6] <= 0.006922470172867179) {
                                                                return 1;
                                                            }

                                                            else {
                                                                if (x[10] <= 0.5) {
                                                                    if (x[5] <= -0.11817843466997147) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        if (x[6] <= 0.006923632463440299) {
                                                                            if (x[3] <= 0.003053911030292511) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                return 1;
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[5] <= -0.11817925795912743) {
                                                                        if (x[5] <= -0.1181795746088028) {
                                                                            if (x[16] <= 0.5) {
                                                                                if (x[5] <= -0.11817968636751175) {
                                                                                    return 1;
                                                                                }

                                                                                else {
                                                                                    return 1;
                                                                                }
                                                                            }

                                                                            else {
                                                                                if (x[5] <= -0.11817989870905876) {
                                                                                    return 0;
                                                                                }

                                                                                else {
                                                                                    if (x[5] <= -0.11817970871925354) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            if (x[5] <= -0.11817507073283195) {
                                                                if (x[0] <= 0.009186149691231549) {
                                                                    if (x[5] <= -0.11817586794495583) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[6] <= 0.006923852255567908) {
                                                                        if (x[5] <= -0.11817654222249985) {
                                                                            return 1;
                                                                        }

                                                                        else {
                                                                            if (x[5] <= -0.1181761622428894) {
                                                                                if (x[16] <= 0.5) {
                                                                                    return 1;
                                                                                }

                                                                                else {
                                                                                    return 1;
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 1;
                                                                            }
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            else {
                                                if (x[5] <= -0.1181732751429081) {
                                                    if (x[5] <= -0.11817354708909988) {
                                                        return 1;
                                                    }

                                                    else {
                                                        if (x[12] <= 0.5) {
                                                            return 0;
                                                        }

                                                        else {
                                                            return 1;
                                                        }
                                                    }
                                                }

                                                else {
                                                    if (x[13] <= 0.5) {
                                                        return 0;
                                                    }

                                                    else {
                                                        if (x[0] <= 0.12659548968076706) {
                                                            return 1;
                                                        }

                                                        else {
                                                            if (x[6] <= 0.006990070454776287) {
                                                                if (x[10] <= 0.5) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    if (x[6] <= 0.006949359551072121) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        else {
                                            if (x[0] <= 0.019859726540744305) {
                                                if (x[5] <= -0.1181819960474968) {
                                                    if (x[12] <= 0.5) {
                                                        if (x[3] <= 6.1651084423065186) {
                                                            if (x[1] <= 2.3410704135894775) {
                                                                return 0;
                                                            }

                                                            else {
                                                                if (x[9] <= 7.514805793762207) {
                                                                    return 0;
                                                                }

                                                                else {
                                                                    if (x[6] <= 0.006920082960277796) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            if (x[3] <= 7.7905144691467285) {
                                                                return 1;
                                                            }

                                                            else {
                                                                return 0;
                                                            }
                                                        }
                                                    }

                                                    else {
                                                        if (x[6] <= 0.0069209623616188765) {
                                                            return 1;
                                                        }

                                                        else {
                                                            return 0;
                                                        }
                                                    }
                                                }

                                                else {
                                                    if (x[9] <= 12.606075286865234) {
                                                        if (x[7] <= 6.612706089392304) {
                                                            if (x[6] <= 0.006921339314430952) {
                                                                if (x[2] <= -0.7577066123485565) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }

                                                            else {
                                                                if (x[6] <= 0.007065995130687952) {
                                                                    return 0;
                                                                }

                                                                else {
                                                                    if (x[3] <= 5.52219033241272) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            if (x[2] <= -1.1140550076961517) {
                                                                return 0;
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }
                                                    }

                                                    else {
                                                        if (x[5] <= -0.11818047240376472) {
                                                            return 0;
                                                        }

                                                        else {
                                                            return 1;
                                                        }
                                                    }
                                                }
                                            }

                                            else {
                                                if (x[9] <= 12.606075286865234) {
                                                    return 0;
                                                }

                                                else {
                                                    return 1;
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            else {
                                if (x[4] <= 3.94312059879303) {
                                    return 0;
                                }

                                else {
                                    if (x[0] <= 1.0605334779247642) {
                                        if (x[2] <= 2.2244125604629517) {
                                            if (x[2] <= 1.992392122745514) {
                                                return 0;
                                            }

                                            else {
                                                if (x[2] <= 2.08782696723938) {
                                                    return 1;
                                                }

                                                else {
                                                    return 0;
                                                }
                                            }
                                        }

                                        else {
                                            return 1;
                                        }
                                    }

                                    else {
                                        return 1;
                                    }
                                }
                            }
                        }

                        else {
                            if (x[1] <= 3.1201990842819214) {
                                if (x[5] <= 2.71464204788208) {
                                    if (x[3] <= 14.22875165939331) {
                                        if (x[2] <= 0.8892006576061249) {
                                            if (x[3] <= 12.453935623168945) {
                                                if (x[3] <= 8.0712251663208) {
                                                    if (x[3] <= 7.414724111557007) {
                                                        if (x[6] <= 4.425620198249817) {
                                                            if (x[3] <= 6.948382139205933) {
                                                                if (x[3] <= 0.5735306590795517) {
                                                                    if (x[3] <= 0.2882922887802124) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[5] <= -0.11818307638168335) {
                                                                        if (x[3] <= 5.4542763233184814) {
                                                                            if (x[8] <= 23.72595412377268) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[3] <= 2.2713781595230103) {
                                                                            if (x[3] <= 2.131022810935974) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                return 1;
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                if (x[9] <= 7.514805793762207) {
                                                                    if (x[3] <= 7.079682350158691) {
                                                                        if (x[7] <= 23.192398929968476) {
                                                                            return 1;
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            if (x[2] <= -1.125437080860138) {
                                                                return 1;
                                                            }

                                                            else {
                                                                return 0;
                                                            }
                                                        }
                                                    }

                                                    else {
                                                        if (x[5] <= -0.1181824840605259) {
                                                            if (x[6] <= 0.016974052414298058) {
                                                                if (x[3] <= 7.926342248916626) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    if (x[3] <= 7.998783588409424) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                return 0;
                                                            }
                                                        }

                                                        else {
                                                            return 0;
                                                        }
                                                    }
                                                }

                                                else {
                                                    if (x[17] <= 0.5) {
                                                        if (x[6] <= 0.015721939504146576) {
                                                            if (x[2] <= 0.35073813796043396) {
                                                                if (x[0] <= 0.030533302575349808) {
                                                                    if (x[3] <= 9.710214138031006) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        if (x[3] <= 9.778128147125244) {
                                                                            return 1;
                                                                        }

                                                                        else {
                                                                            if (x[3] <= 10.869277954101562) {
                                                                                if (x[3] <= 10.33502197265625) {
                                                                                    if (x[9] <= 7.514805793762207) {
                                                                                        if (x[8] <= 23.72595412377268) {
                                                                                            if (x[14] <= 0.5) {
                                                                                                if (x[3] <= 10.04978322982788) {
                                                                                                    return 0;
                                                                                                }

                                                                                                else {
                                                                                                    if (x[3] <= 10.194666385650635) {
                                                                                                        return 0;
                                                                                                    }

                                                                                                    else {
                                                                                                        return 0;
                                                                                                    }
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                return 0;
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    if (x[9] <= 7.514805793762207) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        if (x[5] <= -0.11812899634242058) {
                                                                                            if (x[3] <= 10.475377559661865) {
                                                                                                return 1;
                                                                                            }

                                                                                            else {
                                                                                                if (x[7] <= 23.192398929968476) {
                                                                                                    return 0;
                                                                                                }

                                                                                                else {
                                                                                                    return 1;
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }

                                                                            else {
                                                                                if (x[6] <= 0.009440642781555653) {
                                                                                    if (x[3] <= 11.8925142288208) {
                                                                                        if (x[3] <= 11.820072650909424) {
                                                                                            if (x[3] <= 11.561999320983887) {
                                                                                                return 0;
                                                                                            }

                                                                                            else {
                                                                                                if (x[3] <= 11.629913330078125) {
                                                                                                    return 1;
                                                                                                }

                                                                                                else {
                                                                                                    return 0;
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            return 1;
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    if (x[3] <= 11.5167236328125) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        return 1;
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[6] <= 0.01157281594350934) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                if (x[3] <= 12.02834177017212) {
                                                                    if (x[15] <= 0.5) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            if (x[9] <= -0.13927510380744934) {
                                                                return 1;
                                                            }

                                                            else {
                                                                if (x[2] <= 0.5284745395183563) {
                                                                    if (x[2] <= -0.4433846175670624) {
                                                                        if (x[7] <= 69.61553955078125) {
                                                                            if (x[3] <= 11.127350807189941) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                if (x[3] <= 11.281289100646973) {
                                                                                    return 1;
                                                                                }

                                                                                else {
                                                                                    if (x[3] <= 11.883458614349365) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        if (x[3] <= 12.005703449249268) {
                                                                                            return 1;
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }

                                                                        else {
                                                                            if (x[3] <= 9.782655239105225) {
                                                                                if (x[3] <= 8.863554000854492) {
                                                                                    return 0;
                                                                                }

                                                                                else {
                                                                                    return 1;
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[9] <= -0.02652726322412491) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            if (x[6] <= 0.1469664853066206) {
                                                                                return 1;
                                                                            }

                                                                            else {
                                                                                if (x[2] <= -0.0739030223339796) {
                                                                                    if (x[2] <= -0.14307137206196785) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        return 1;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    return 0;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }
                                                        }
                                                    }

                                                    else {
                                                        return 1;
                                                    }
                                                }
                                            }

                                            else {
                                                if (x[3] <= 12.539959907531738) {
                                                    if (x[9] <= 7.514805793762207) {
                                                        return 0;
                                                    }

                                                    else {
                                                        return 1;
                                                    }
                                                }

                                                else {
                                                    if (x[3] <= 14.19705867767334) {
                                                        if (x[3] <= 13.839378833770752) {
                                                            if (x[3] <= 13.404730319976807) {
                                                                if (x[2] <= 0.8200322687625885) {
                                                                    if (x[3] <= 12.95197057723999) {
                                                                        if (x[9] <= 7.514805793762207) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[3] <= 13.264374732971191) {
                                                                            if (x[5] <= -0.11812899634242058) {
                                                                                if (x[3] <= 13.137601852416992) {
                                                                                    return 0;
                                                                                }

                                                                                else {
                                                                                    if (x[3] <= 13.191933155059814) {
                                                                                        return 1;
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }
                                                                            }

                                                                            else {
                                                                                if (x[9] <= 6.290875151753426) {
                                                                                    return 0;
                                                                                }

                                                                                else {
                                                                                    return 1;
                                                                                }
                                                                            }
                                                                        }

                                                                        else {
                                                                            if (x[3] <= 13.33228874206543) {
                                                                                return 1;
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }

                                                            else {
                                                                if (x[3] <= 13.676385402679443) {
                                                                    if (x[3] <= 13.563196182250977) {
                                                                        if (x[3] <= 13.486226558685303) {
                                                                            return 1;
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[6] <= 0.009436245076358318) {
                                                                            return 1;
                                                                        }

                                                                        else {
                                                                            if (x[7] <= 23.192398929968476) {
                                                                                if (x[3] <= 13.61752700805664) {
                                                                                    return 1;
                                                                                }

                                                                                else {
                                                                                    return 0;
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 1;
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[6] <= 1.2734859064221382) {
                                                                        if (x[3] <= 13.807685852050781) {
                                                                            if (x[3] <= 13.766937732696533) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                if (x[6] <= 0.009436245076358318) {
                                                                                    if (x[9] <= 7.514805793762207) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        return 1;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    return 0;
                                                                                }
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            if (x[3] <= 14.106507301330566) {
                                                                if (x[3] <= 14.03859281539917) {
                                                                    if (x[6] <= 0.009436245076358318) {
                                                                        if (x[3] <= 13.93898630142212) {
                                                                            if (x[7] <= 23.192398929968476) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                return 1;
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[7] <= 69.61553955078125) {
                                                                            if (x[3] <= 13.893710136413574) {
                                                                                return 1;
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[3] <= 14.083869457244873) {
                                                                        if (x[8] <= 23.72595412377268) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[8] <= 23.72595412377268) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }
                                                    }

                                                    else {
                                                        if (x[7] <= 23.192398929968476) {
                                                            if (x[9] <= 7.514805793762207) {
                                                                return 0;
                                                            }

                                                            else {
                                                                return 0;
                                                            }
                                                        }

                                                        else {
                                                            return 0;
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        else {
                                            if (x[9] <= 7.514805793762207) {
                                                if (x[15] <= 0.5) {
                                                    return 1;
                                                }

                                                else {
                                                    return 0;
                                                }
                                            }

                                            else {
                                                if (x[2] <= 0.9653733968734741) {
                                                    if (x[2] <= 0.9513646066188812) {
                                                        return 1;
                                                    }

                                                    else {
                                                        return 0;
                                                    }
                                                }

                                                else {
                                                    return 1;
                                                }
                                            }
                                        }
                                    }

                                    else {
                                        if (x[3] <= 15.56439208984375) {
                                            if (x[9] <= 7.514805793762207) {
                                                if (x[7] <= 29.824275970458984) {
                                                    if (x[3] <= 14.57737684249878) {
                                                        if (x[6] <= 1.277882399968803) {
                                                            return 0;
                                                        }

                                                        else {
                                                            return 1;
                                                        }
                                                    }

                                                    else {
                                                        return 0;
                                                    }
                                                }

                                                else {
                                                    if (x[6] <= 0.1407460067421198) {
                                                        if (x[0] <= -0.012161002960056067) {
                                                            if (x[3] <= 14.581904411315918) {
                                                                return 0;
                                                            }

                                                            else {
                                                                if (x[3] <= 15.075412273406982) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            return 1;
                                                        }
                                                    }

                                                    else {
                                                        return 0;
                                                    }
                                                }
                                            }

                                            else {
                                                if (x[2] <= 1.0091508328914642) {
                                                    if (x[3] <= 15.256515502929688) {
                                                        return 0;
                                                    }

                                                    else {
                                                        if (x[3] <= 15.31084680557251) {
                                                            return 1;
                                                        }

                                                        else {
                                                            return 0;
                                                        }
                                                    }
                                                }

                                                else {
                                                    if (x[2] <= 1.0345417261123657) {
                                                        return 0;
                                                    }

                                                    else {
                                                        if (x[3] <= 15.143325805664062) {
                                                            if (x[2] <= 1.116843342781067) {
                                                                return 0;
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }

                                                        else {
                                                            return 0;
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        else {
                                            if (x[3] <= 15.577974796295166) {
                                                return 1;
                                            }

                                            else {
                                                if (x[6] <= 0.009441899601370096) {
                                                    if (x[2] <= 2.374131441116333) {
                                                        if (x[3] <= 19.76599884033203) {
                                                            if (x[2] <= 2.0265384912490845) {
                                                                if (x[3] <= 19.598477363586426) {
                                                                    if (x[9] <= 7.514805793762207) {
                                                                        if (x[7] <= 23.192398929968476) {
                                                                            if (x[3] <= 16.4201078414917) {
                                                                                return 1;
                                                                            }

                                                                            else {
                                                                                if (x[3] <= 17.053970336914062) {
                                                                                    return 0;
                                                                                }

                                                                                else {
                                                                                    return 1;
                                                                                }
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[3] <= 19.440011978149414) {
                                                                            if (x[3] <= 19.372097969055176) {
                                                                                if (x[2] <= 1.4171565175056458) {
                                                                                    if (x[3] <= 19.09138774871826) {
                                                                                        if (x[3] <= 17.266767501831055) {
                                                                                            if (x[3] <= 16.981528282165527) {
                                                                                                if (x[3] <= 16.406524658203125) {
                                                                                                    if (x[2] <= 1.3488637804985046) {
                                                                                                        if (x[3] <= 16.171090126037598) {
                                                                                                            if (x[3] <= 16.10770320892334) {
                                                                                                                if (x[2] <= 1.280570924282074) {
                                                                                                                    if (x[3] <= 15.849630355834961) {
                                                                                                                        if (x[3] <= 15.641360759735107) {
                                                                                                                            if (x[0] <= -0.012161002960056067) {
                                                                                                                                if (x[7] <= 23.192398929968476) {
                                                                                                                                    return 0;
                                                                                                                                }

                                                                                                                                else {
                                                                                                                                    return 0;
                                                                                                                                }
                                                                                                                            }

                                                                                                                            else {
                                                                                                                                return 0;
                                                                                                                            }
                                                                                                                        }

                                                                                                                        else {
                                                                                                                            if (x[3] <= 15.750023365020752) {
                                                                                                                                if (x[0] <= -0.012161002960056067) {
                                                                                                                                    if (x[8] <= 23.72595412377268) {
                                                                                                                                        return 0;
                                                                                                                                    }

                                                                                                                                    else {
                                                                                                                                        return 0;
                                                                                                                                    }
                                                                                                                                }

                                                                                                                                else {
                                                                                                                                    return 1;
                                                                                                                                }
                                                                                                                            }

                                                                                                                            else {
                                                                                                                                if (x[5] <= -0.11812899634242058) {
                                                                                                                                    if (x[8] <= 23.72595412377268) {
                                                                                                                                        return 0;
                                                                                                                                    }

                                                                                                                                    else {
                                                                                                                                        return 0;
                                                                                                                                    }
                                                                                                                                }

                                                                                                                                else {
                                                                                                                                    return 0;
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        if (x[3] <= 15.994513511657715) {
                                                                                                                            if (x[3] <= 15.922071933746338) {
                                                                                                                                return 0;
                                                                                                                            }

                                                                                                                            else {
                                                                                                                                if (x[8] <= 23.72595412377268) {
                                                                                                                                    return 0;
                                                                                                                                }

                                                                                                                                else {
                                                                                                                                    return 0;
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }

                                                                                                                        else {
                                                                                                                            return 0;
                                                                                                                        }
                                                                                                                    }
                                                                                                                }

                                                                                                                else {
                                                                                                                    if (x[3] <= 16.066954612731934) {
                                                                                                                        return 1;
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        return 0;
                                                                                                                    }
                                                                                                                }
                                                                                                            }

                                                                                                            else {
                                                                                                                return 1;
                                                                                                            }
                                                                                                        }

                                                                                                        else {
                                                                                                            if (x[3] <= 16.229948043823242) {
                                                                                                                return 0;
                                                                                                            }

                                                                                                            else {
                                                                                                                if (x[3] <= 16.315972328186035) {
                                                                                                                    return 1;
                                                                                                                }

                                                                                                                else {
                                                                                                                    return 0;
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }

                                                                                                    else {
                                                                                                        return 1;
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    if (x[3] <= 16.456327438354492) {
                                                                                                        return 1;
                                                                                                    }

                                                                                                    else {
                                                                                                        if (x[3] <= 16.515186309814453) {
                                                                                                            return 0;
                                                                                                        }

                                                                                                        else {
                                                                                                            if (x[3] <= 16.59668254852295) {
                                                                                                                return 1;
                                                                                                            }

                                                                                                            else {
                                                                                                                if (x[3] <= 16.655542373657227) {
                                                                                                                    return 0;
                                                                                                                }

                                                                                                                else {
                                                                                                                    if (x[3] <= 16.723456382751465) {
                                                                                                                        return 1;
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        if (x[3] <= 16.773259162902832) {
                                                                                                                            return 0;
                                                                                                                        }

                                                                                                                        else {
                                                                                                                            if (x[3] <= 16.84570026397705) {
                                                                                                                                if (x[7] <= 23.192398929968476) {
                                                                                                                                    return 0;
                                                                                                                                }

                                                                                                                                else {
                                                                                                                                    return 0;
                                                                                                                                }
                                                                                                                            }

                                                                                                                            else {
                                                                                                                                if (x[7] <= 23.192398929968476) {
                                                                                                                                    return 0;
                                                                                                                                }

                                                                                                                                else {
                                                                                                                                    return 0;
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                if (x[8] <= 23.72595412377268) {
                                                                                                    if (x[3] <= 17.126412391662598) {
                                                                                                        if (x[3] <= 17.053970336914062) {
                                                                                                            return 0;
                                                                                                        }

                                                                                                        else {
                                                                                                            return 0;
                                                                                                        }
                                                                                                    }

                                                                                                    else {
                                                                                                        if (x[3] <= 17.198853492736816) {
                                                                                                            return 0;
                                                                                                        }

                                                                                                        else {
                                                                                                            return 0;
                                                                                                        }
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    if (x[3] <= 17.053970336914062) {
                                                                                                        return 1;
                                                                                                    }

                                                                                                    else {
                                                                                                        if (x[3] <= 17.198853492736816) {
                                                                                                            if (x[3] <= 17.126412391662598) {
                                                                                                                return 0;
                                                                                                            }

                                                                                                            else {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        }

                                                                                                        else {
                                                                                                            return 1;
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            if (x[3] <= 17.701416015625) {
                                                                                                return 0;
                                                                                            }

                                                                                            else {
                                                                                                if (x[3] <= 17.76027488708496) {
                                                                                                    return 1;
                                                                                                }

                                                                                                else {
                                                                                                    if (x[3] <= 17.905158042907715) {
                                                                                                        if (x[3] <= 17.787440299987793) {
                                                                                                            return 0;
                                                                                                        }

                                                                                                        else {
                                                                                                            if (x[8] <= 23.72595412377268) {
                                                                                                                if (x[3] <= 17.846299171447754) {
                                                                                                                    return 1;
                                                                                                                }

                                                                                                                else {
                                                                                                                    return 1;
                                                                                                                }
                                                                                                            }

                                                                                                            else {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        }
                                                                                                    }

                                                                                                    else {
                                                                                                        if (x[3] <= 18.371499061584473) {
                                                                                                            if (x[3] <= 18.095316886901855) {
                                                                                                                return 0;
                                                                                                            }

                                                                                                            else {
                                                                                                                if (x[3] <= 18.136064529418945) {
                                                                                                                    return 1;
                                                                                                                }

                                                                                                                else {
                                                                                                                    if (x[3] <= 18.18586826324463) {
                                                                                                                        if (x[7] <= 23.192398929968476) {
                                                                                                                            if (x[3] <= 18.17228603363037) {
                                                                                                                                return 0;
                                                                                                                            }

                                                                                                                            else {
                                                                                                                                return 0;
                                                                                                                            }
                                                                                                                        }

                                                                                                                        else {
                                                                                                                            return 0;
                                                                                                                        }
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        if (x[3] <= 18.235671997070312) {
                                                                                                                            return 0;
                                                                                                                        }

                                                                                                                        else {
                                                                                                                            if (x[3] <= 18.280948638916016) {
                                                                                                                                if (x[7] <= 23.192398929968476) {
                                                                                                                                    return 0;
                                                                                                                                }

                                                                                                                                else {
                                                                                                                                    return 0;
                                                                                                                                }
                                                                                                                            }

                                                                                                                            else {
                                                                                                                                if (x[3] <= 18.330751419067383) {
                                                                                                                                    if (x[3] <= 18.31716823577881) {
                                                                                                                                        return 0;
                                                                                                                                    }

                                                                                                                                    else {
                                                                                                                                        if (x[7] <= 23.192398929968476) {
                                                                                                                                            return 0;
                                                                                                                                        }

                                                                                                                                        else {
                                                                                                                                            return 0;
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }

                                                                                                                                else {
                                                                                                                                    return 0;
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }

                                                                                                        else {
                                                                                                            if (x[3] <= 18.389610290527344) {
                                                                                                                return 1;
                                                                                                            }

                                                                                                            else {
                                                                                                                if (x[3] <= 18.534493446350098) {
                                                                                                                    if (x[3] <= 18.516383171081543) {
                                                                                                                        if (x[3] <= 18.452996253967285) {
                                                                                                                            return 0;
                                                                                                                        }

                                                                                                                        else {
                                                                                                                            if (x[3] <= 18.484689712524414) {
                                                                                                                                if (x[8] <= 23.72595412377268) {
                                                                                                                                    if (x[3] <= 18.46657943725586) {
                                                                                                                                        return 0;
                                                                                                                                    }

                                                                                                                                    else {
                                                                                                                                        return 0;
                                                                                                                                    }
                                                                                                                                }

                                                                                                                                else {
                                                                                                                                    if (x[3] <= 18.46657943725586) {
                                                                                                                                        return 0;
                                                                                                                                    }

                                                                                                                                    else {
                                                                                                                                        return 0;
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }

                                                                                                                            else {
                                                                                                                                if (x[3] <= 18.50279998779297) {
                                                                                                                                    return 0;
                                                                                                                                }

                                                                                                                                else {
                                                                                                                                    return 0;
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        return 1;
                                                                                                                    }
                                                                                                                }

                                                                                                                else {
                                                                                                                    if (x[3] <= 18.892172813415527) {
                                                                                                                        if (x[3] <= 18.80614948272705) {
                                                                                                                            if (x[3] <= 18.679375648498535) {
                                                                                                                                if (x[3] <= 18.62504482269287) {
                                                                                                                                    if (x[3] <= 18.611462593078613) {
                                                                                                                                        if (x[8] <= 23.72595412377268) {
                                                                                                                                            return 0;
                                                                                                                                        }

                                                                                                                                        else {
                                                                                                                                            if (x[3] <= 18.579769134521484) {
                                                                                                                                                return 0;
                                                                                                                                            }

                                                                                                                                            else {
                                                                                                                                                return 0;
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }

                                                                                                                                    else {
                                                                                                                                        if (x[7] <= 23.192398929968476) {
                                                                                                                                            return 0;
                                                                                                                                        }

                                                                                                                                        else {
                                                                                                                                            return 0;
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }

                                                                                                                                else {
                                                                                                                                    if (x[3] <= 18.638628005981445) {
                                                                                                                                        return 1;
                                                                                                                                    }

                                                                                                                                    else {
                                                                                                                                        if (x[3] <= 18.65673828125) {
                                                                                                                                            return 0;
                                                                                                                                        }

                                                                                                                                        else {
                                                                                                                                            return 1;
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }

                                                                                                                            else {
                                                                                                                                if (x[7] <= 23.192398929968476) {
                                                                                                                                    if (x[3] <= 18.756345748901367) {
                                                                                                                                        if (x[3] <= 18.738234519958496) {
                                                                                                                                            return 0;
                                                                                                                                        }

                                                                                                                                        else {
                                                                                                                                            return 0;
                                                                                                                                        }
                                                                                                                                    }

                                                                                                                                    else {
                                                                                                                                        return 0;
                                                                                                                                    }
                                                                                                                                }

                                                                                                                                else {
                                                                                                                                    return 0;
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }

                                                                                                                        else {
                                                                                                                            if (x[3] <= 18.860480308532715) {
                                                                                                                                return 1;
                                                                                                                            }

                                                                                                                            else {
                                                                                                                                return 0;
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        return 0;
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        if (x[3] <= 19.1593017578125) {
                                                                                            return 1;
                                                                                        }

                                                                                        else {
                                                                                            if (x[8] <= 23.72595412377268) {
                                                                                                if (x[3] <= 19.295129776000977) {
                                                                                                    if (x[3] <= 19.22721576690674) {
                                                                                                        return 0;
                                                                                                    }

                                                                                                    else {
                                                                                                        return 1;
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    if (x[3] <= 19.31776714324951) {
                                                                                                        return 0;
                                                                                                    }

                                                                                                    else {
                                                                                                        return 0;
                                                                                                    }
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                if (x[3] <= 19.245326042175293) {
                                                                                                    return 0;
                                                                                                }

                                                                                                else {
                                                                                                    if (x[3] <= 19.31776714324951) {
                                                                                                        return 1;
                                                                                                    }

                                                                                                    else {
                                                                                                        return 0;
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    if (x[2] <= 1.5677509903907776) {
                                                                                        if (x[2] <= 1.553742229938507) {
                                                                                            if (x[8] <= 23.72595412377268) {
                                                                                                if (x[3] <= 16.700818061828613) {
                                                                                                    return 0;
                                                                                                }

                                                                                                else {
                                                                                                    if (x[3] <= 16.954362869262695) {
                                                                                                        return 0;
                                                                                                    }

                                                                                                    else {
                                                                                                        if (x[3] <= 17.022276878356934) {
                                                                                                            return 1;
                                                                                                        }

                                                                                                        else {
                                                                                                            if (x[2] <= 1.499458134174347) {
                                                                                                                if (x[2] <= 1.4854493737220764) {
                                                                                                                    return 0;
                                                                                                                }

                                                                                                                else {
                                                                                                                    return 0;
                                                                                                                }
                                                                                                            }

                                                                                                            else {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                if (x[3] <= 16.886448860168457) {
                                                                                                    if (x[2] <= 1.439045250415802) {
                                                                                                        if (x[3] <= 16.700818061828613) {
                                                                                                            return 0;
                                                                                                        }

                                                                                                        else {
                                                                                                            return 0;
                                                                                                        }
                                                                                                    }

                                                                                                    else {
                                                                                                        return 1;
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    if (x[2] <= 1.4854493737220764) {
                                                                                                        return 1;
                                                                                                    }

                                                                                                    else {
                                                                                                        return 0;
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            return 1;
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        if (x[2] <= 1.6360437273979187) {
                                                                                            return 0;
                                                                                        }

                                                                                        else {
                                                                                            if (x[2] <= 1.7446117997169495) {
                                                                                                if (x[2] <= 1.7183453440666199) {
                                                                                                    if (x[2] <= 1.6640613675117493) {
                                                                                                        if (x[3] <= 17.837244033813477) {
                                                                                                            return 0;
                                                                                                        }

                                                                                                        else {
                                                                                                            return 1;
                                                                                                        }
                                                                                                    }

                                                                                                    else {
                                                                                                        if (x[3] <= 17.837244033813477) {
                                                                                                            return 1;
                                                                                                        }

                                                                                                        else {
                                                                                                            if (x[3] <= 17.977599143981934) {
                                                                                                                return 0;
                                                                                                            }

                                                                                                            else {
                                                                                                                if (x[2] <= 1.6912033557891846) {
                                                                                                                    return 0;
                                                                                                                }

                                                                                                                else {
                                                                                                                    if (x[7] <= 23.192398929968476) {
                                                                                                                        return 0;
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        return 0;
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    return 1;
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                if (x[3] <= 18.611462593078613) {
                                                                                                    return 0;
                                                                                                }

                                                                                                else {
                                                                                                    if (x[2] <= 1.8873263001441956) {
                                                                                                        if (x[2] <= 1.876819670200348) {
                                                                                                            if (x[3] <= 18.8604793548584) {
                                                                                                                if (x[3] <= 18.69295883178711) {
                                                                                                                    if (x[2] <= 1.8417977094650269) {
                                                                                                                        return 0;
                                                                                                                    }

                                                                                                                    else {
                                                                                                                        if (x[3] <= 18.62504482269287) {
                                                                                                                            return 1;
                                                                                                                        }

                                                                                                                        else {
                                                                                                                            return 0;
                                                                                                                        }
                                                                                                                    }
                                                                                                                }

                                                                                                                else {
                                                                                                                    return 1;
                                                                                                                }
                                                                                                            }

                                                                                                            else {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        }

                                                                                                        else {
                                                                                                            return 1;
                                                                                                        }
                                                                                                    }

                                                                                                    else {
                                                                                                        if (x[3] <= 19.281546592712402) {
                                                                                                            return 0;
                                                                                                        }

                                                                                                        else {
                                                                                                            if (x[2] <= 1.9372325539588928) {
                                                                                                                return 1;
                                                                                                            }

                                                                                                            else {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 1;
                                                                            }
                                                                        }

                                                                        else {
                                                                            if (x[3] <= 19.462650299072266) {
                                                                                if (x[8] <= 23.72595412377268) {
                                                                                    if (x[2] <= 0.07669132947921753) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    return 0;
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[3] <= 19.639225959777832) {
                                                                        if (x[7] <= 23.192398929968476) {
                                                                            if (x[5] <= -0.11812899634242058) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }

                                                                        else {
                                                                            if (x[2] <= 2.0055253505706787) {
                                                                                if (x[0] <= -0.012161002960056067) {
                                                                                    return 1;
                                                                                }

                                                                                else {
                                                                                    return 1;
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[3] <= 19.74336051940918) {
                                                                            if (x[3] <= 19.70713996887207) {
                                                                                if (x[5] <= -0.11812899634242058) {
                                                                                    return 1;
                                                                                }

                                                                                else {
                                                                                    return 0;
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }

                                                                        else {
                                                                            if (x[7] <= 23.192398929968476) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                if (x[2] <= 2.039671778678894) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            if (x[3] <= 20.63982391357422) {
                                                                if (x[2] <= 2.156119704246521) {
                                                                    if (x[3] <= 20.168954849243164) {
                                                                        if (x[3] <= 19.919937133789062) {
                                                                            if (x[7] <= 23.192398929968476) {
                                                                                if (x[3] <= 19.852023124694824) {
                                                                                    return 0;
                                                                                }

                                                                                else {
                                                                                    return 0;
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[8] <= 23.72595412377268) {
                                                                            if (x[3] <= 20.241395950317383) {
                                                                                if (x[2] <= 0.1449841856956482) {
                                                                                    return 0;
                                                                                }

                                                                                else {
                                                                                    return 0;
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }

                                                                        else {
                                                                            if (x[3] <= 20.490413665771484) {
                                                                                if (x[3] <= 20.377223014831543) {
                                                                                    if (x[3] <= 20.241395950317383) {
                                                                                        if (x[4] <= -1.5458661168813705) {
                                                                                            return 0;
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    if (x[3] <= 20.449665069580078) {
                                                                                        return 1;
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[2] <= 2.1823861598968506) {
                                                                        if (x[3] <= 20.449665069580078) {
                                                                            if (x[3] <= 20.377223014831543) {
                                                                                return 0;
                                                                            }

                                                                            else {
                                                                                return 1;
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                if (x[3] <= 22.360309600830078) {
                                                                    if (x[3] <= 21.17407989501953) {
                                                                        if (x[3] <= 21.060890197753906) {
                                                                            if (x[3] <= 20.888842582702637) {
                                                                                if (x[3] <= 20.811872482299805) {
                                                                                    if (x[3] <= 20.73037624359131) {
                                                                                        if (x[8] <= 23.72595412377268) {
                                                                                            if (x[6] <= 0.009436245076358318) {
                                                                                                if (x[3] <= 20.69868278503418) {
                                                                                                    return 0;
                                                                                                }

                                                                                                else {
                                                                                                    return 0;
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                return 0;
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        if (x[3] <= 20.7711238861084) {
                                                                                            if (x[3] <= 20.743958473205566) {
                                                                                                if (x[8] <= 23.72595412377268) {
                                                                                                    if (x[6] <= 0.009436245076358318) {
                                                                                                        return 0;
                                                                                                    }

                                                                                                    else {
                                                                                                        return 0;
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    return 0;
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                return 0;
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            if (x[3] <= 20.79828929901123) {
                                                                                                return 1;
                                                                                            }

                                                                                            else {
                                                                                                return 0;
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    if (x[7] <= 23.192398929968476) {
                                                                                        if (x[3] <= 20.843565940856934) {
                                                                                            return 1;
                                                                                        }

                                                                                        else {
                                                                                            if (x[5] <= -0.11812899634242058) {
                                                                                                if (x[3] <= 20.875259399414062) {
                                                                                                    return 0;
                                                                                                }

                                                                                                else {
                                                                                                    return 0;
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                if (x[2] <= 2.2655632495880127) {
                                                                                                    return 1;
                                                                                                }

                                                                                                else {
                                                                                                    return 0;
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        if (x[3] <= 20.875259399414062) {
                                                                                            return 1;
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }

                                                                            else {
                                                                                if (x[3] <= 20.934117317199707) {
                                                                                    if (x[3] <= 20.911479949951172) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        return 1;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    return 0;
                                                                                }
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 1;
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[3] <= 21.93471622467041) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            if (x[3] <= 22.00715732574463) {
                                                                                return 1;
                                                                            }

                                                                            else {
                                                                                if (x[8] <= 23.72595412377268) {
                                                                                    if (x[3] <= 22.079598426818848) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    return 0;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }
                                                        }
                                                    }

                                                    else {
                                                        if (x[3] <= 21.513649940490723) {
                                                            return 0;
                                                        }

                                                        else {
                                                            return 1;
                                                        }
                                                    }
                                                }

                                                else {
                                                    if (x[6] <= 0.26048266887664795) {
                                                        if (x[3] <= 16.700817108154297) {
                                                            if (x[3] <= 15.994513511657715) {
                                                                if (x[6] <= 0.018236217088997364) {
                                                                    return 0;
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }

                                                        else {
                                                            if (x[3] <= 19.58036708831787) {
                                                                if (x[3] <= 18.18586826324463) {
                                                                    if (x[3] <= 17.628973960876465) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        if (x[3] <= 17.977599143981934) {
                                                                            return 1;
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[3] <= 18.262837409973145) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        if (x[3] <= 18.52091121673584) {
                                                                            return 0;
                                                                        }

                                                                        else {
                                                                            if (x[6] <= 0.1342718326486647) {
                                                                                if (x[2] <= -0.002983570098876953) {
                                                                                    if (x[3] <= 18.941977500915527) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        return 1;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    return 1;
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 0;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                if (x[9] <= 7.514805793762207) {
                                                                    return 0;
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }
                                                        }
                                                    }

                                                    else {
                                                        if (x[6] <= 2.528745651245117) {
                                                            if (x[3] <= 20.368167877197266) {
                                                                if (x[3] <= 20.300253868103027) {
                                                                    if (x[3] <= 17.60633659362793) {
                                                                        if (x[9] <= 7.514805793762207) {
                                                                            if (x[7] <= 69.61553955078125) {
                                                                                if (x[3] <= 16.420106887817383) {
                                                                                    if (x[3] <= 16.27522373199463) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    return 0;
                                                                                }
                                                                            }

                                                                            else {
                                                                                if (x[3] <= 16.27522373199463) {
                                                                                    return 0;
                                                                                }

                                                                                else {
                                                                                    return 1;
                                                                                }
                                                                            }
                                                                        }

                                                                        else {
                                                                            return 0;
                                                                        }
                                                                    }

                                                                    else {
                                                                        if (x[3] <= 17.674250602722168) {
                                                                            return 1;
                                                                        }

                                                                        else {
                                                                            if (x[3] <= 19.46264934539795) {
                                                                                if (x[3] <= 18.87859058380127) {
                                                                                    if (x[3] <= 18.68843173980713) {
                                                                                        if (x[7] <= 69.61553955078125) {
                                                                                            if (x[3] <= 18.511855125427246) {
                                                                                                if (x[3] <= 18.24925422668457) {
                                                                                                    if (x[3] <= 18.17681312561035) {
                                                                                                        return 0;
                                                                                                    }

                                                                                                    else {
                                                                                                        return 1;
                                                                                                    }
                                                                                                }

                                                                                                else {
                                                                                                    return 0;
                                                                                                }
                                                                                            }

                                                                                            else {
                                                                                                if (x[3] <= 18.570713996887207) {
                                                                                                    return 1;
                                                                                                }

                                                                                                else {
                                                                                                    return 0;
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            if (x[6] <= 1.8336967825889587) {
                                                                                                return 0;
                                                                                            }

                                                                                            else {
                                                                                                if (x[3] <= 18.31716823577881) {
                                                                                                    return 0;
                                                                                                }

                                                                                                else {
                                                                                                    return 1;
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        if (x[3] <= 18.855952262878418) {
                                                                                            return 1;
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    return 1;
                                                                                }
                                                                            }

                                                                            else {
                                                                                if (x[3] <= 20.168954849243164) {
                                                                                    if (x[3] <= 20.015016555786133) {
                                                                                        return 0;
                                                                                    }

                                                                                    else {
                                                                                        if (x[3] <= 20.08745765686035) {
                                                                                            if (x[8] <= 23.72595412377268) {
                                                                                                return 0;
                                                                                            }

                                                                                            else {
                                                                                                return 0;
                                                                                            }
                                                                                        }

                                                                                        else {
                                                                                            return 0;
                                                                                        }
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    if (x[3] <= 20.227813720703125) {
                                                                                        return 1;
                                                                                    }

                                                                                    else {
                                                                                        return 0;
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[4] <= -1.5458661168813705) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                return 0;
                                                            }
                                                        }

                                                        else {
                                                            if (x[3] <= 18.18586826324463) {
                                                                if (x[2] <= -0.8811590373516083) {
                                                                    if (x[4] <= -1.5458661168813705) {
                                                                        return 0;
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }

                                                            else {
                                                                if (x[2] <= 1.7997713685035706) {
                                                                    if (x[3] <= 20.354585647583008) {
                                                                        if (x[6] <= 2.5431898832321167) {
                                                                            if (x[3] <= 20.02407169342041) {
                                                                                if (x[2] <= 0.8235344588756561) {
                                                                                    if (x[6] <= 2.5343973636627197) {
                                                                                        if (x[8] <= 71.21702575683594) {
                                                                                            return 0;
                                                                                        }

                                                                                        else {
                                                                                            return 1;
                                                                                        }
                                                                                    }

                                                                                    else {
                                                                                        return 1;
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    return 1;
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 1;
                                                                            }
                                                                        }

                                                                        else {
                                                                            if (x[5] <= -0.11267213150858879) {
                                                                                if (x[3] <= 19.462650299072266) {
                                                                                    return 0;
                                                                                }

                                                                                else {
                                                                                    return 1;
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 1;
                                                                            }
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 0;
                                                                    }
                                                                }

                                                                else {
                                                                    return 0;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                else {
                                    if (x[1] <= 1.0661324709653854) {
                                        return 0;
                                    }

                                    else {
                                        return 1;
                                    }
                                }
                            }

                            else {
                                if (x[13] <= 0.5) {
                                    return 0;
                                }

                                else {
                                    return 1;
                                }
                            }
                        }
                    }

                protected:
                };
            }
        }
    }
