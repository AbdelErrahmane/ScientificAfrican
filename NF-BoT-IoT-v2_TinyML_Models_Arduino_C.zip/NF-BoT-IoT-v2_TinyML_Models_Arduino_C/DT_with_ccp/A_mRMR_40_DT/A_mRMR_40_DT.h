#pragma once
namespace Eloquent {
    namespace ML {
        namespace Port {
            class DecisionTree {
                public:
                    /**
                    * Predict class for features vector
                    */
                    int predict(float *x) {
                        if (x[6] <= 0.00907239131629467) {
                            if (x[4] <= 2.103878989815712) {
                                if (x[20] <= 0.5) {
                                    if (x[9] <= 1.2995810508728027) {
                                        return 1;
                                    }

                                    else {
                                        if (x[15] <= 0.5) {
                                            return 1;
                                        }

                                        else {
                                            return 0;
                                        }
                                    }
                                }

                                else {
                                    return 0;
                                }
                            }

                            else {
                                return 0;
                            }
                        }

                        else {
                            return 0;
                        }
                    }

                protected:
                };
            }
        }
    }
