#pragma once
namespace Eloquent {
    namespace ML {
        namespace Port {
            class DecisionTree {
                public:
                    /**
                    * Predict class for features vector
                    */
                    int predict(float *x) {
                        if (x[4] <= 1.2995810508728027) {
                            if (x[1] <= -0.11818376183509827) {
                                return 0;
                            }

                            else {
                                if (x[9] <= 0.5) {
                                    if (x[5] <= 0.5) {
                                        return 1;
                                    }

                                    else {
                                        if (x[4] <= 0.13686902076005936) {
                                            return 0;
                                        }

                                        else {
                                            return 1;
                                        }
                                    }
                                }

                                else {
                                    return 0;
                                }
                            }
                        }

                        else {
                            if (x[1] <= -0.11818283051252365) {
                                return 0;
                            }

                            else {
                                if (x[0] <= 6.233022212982178) {
                                    return 1;
                                }

                                else {
                                    return 0;
                                }
                            }
                        }
                    }

                protected:
                };
            }
        }
    }
