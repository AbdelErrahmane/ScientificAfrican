#pragma once
namespace Eloquent {
    namespace ML {
        namespace Port {
            class DecisionTree {
                public:
                    /**
                    * Predict class for features vector
                    */
                    int predict(float *x) {
                        if (x[9] <= 0.00907239131629467) {
                            if (x[6] <= 2.103878989815712) {
                                if (x[22] <= 0.5) {
                                    return 0;
                                }

                                else {
                                    if (x[14] <= 1.2995810508728027) {
                                        if (x[26] <= 0.5) {
                                            return 0;
                                        }

                                        else {
                                            if (x[19] <= 0.5) {
                                                return 1;
                                            }

                                            else {
                                                if (x[8] <= -0.11818307638168335) {
                                                    return 0;
                                                }

                                                else {
                                                    return 1;
                                                }
                                            }
                                        }
                                    }

                                    else {
                                        if (x[28] <= 0.5) {
                                            return 1;
                                        }

                                        else {
                                            return 0;
                                        }
                                    }
                                }
                            }

                            else {
                                return 0;
                            }
                        }

                        else {
                            return 0;
                        }
                    }

                protected:
                };
            }
        }
    }
